"""構造化スキーマ定義。

VLM に出力させるのは SheetExtraction / CardFields / JudgeVerdict の 3 つ。
すべて extra="forbid" (additionalProperties: false) にして guided decoding の
文法を閉じ、語彙のブレを排除する。
"""
from __future__ import annotations

from typing import Literal, Optional

from pydantic import BaseModel, ConfigDict, Field


class StrictModel(BaseModel):
    model_config = ConfigDict(extra="forbid")


# 名刺から抽出するフィールド名 = ルール条件が参照できるフィールド名 (閉集合にする)
FieldName = Literal[
    "company",
    "department",
    "title",
    "person_name",
    "email",
    "email_domain",
    "phone",
    "address",
    "other",
]

ConditionOp = Literal[
    "equals",        # 正規化後の完全一致 (values のいずれか)
    "not_equals",
    "contains",      # 部分一致 (values のいずれか)
    "not_contains",
    "regex",         # values の各要素を正規表現として正規化済み文字列に search
    "semantic",      # 決定的に判定できない自然文条件 → LLM judge 送り
]


class RuleCondition(StrictModel):
    field: FieldName
    op: ConditionOp
    values: list[str] = Field(
        description="候補値のリスト。equals/contains は「いずれかに一致」で真。"
        "semantic の場合は自然文の条件を 1 要素で入れる。"
    )
    note: Optional[str] = None


class SourceRef(StrictModel):
    sheet: str
    cell_range: str = Field(description='例: "B4:D12"。おおよそで良いが必ず埋める。')


class BusinessRule(StrictModel):
    rule_id: str
    name: str
    when_all: list[RuleCondition] = Field(default_factory=list, description="全て満たす")
    when_any: list[RuleCondition] = Field(default_factory=list, description="いずれか満たす")
    exceptions: list[RuleCondition] = Field(
        default_factory=list, description="いずれかに該当したら本ルールを適用しない"
    )
    action: str = Field(description="適用時の処理内容 (ルーティング先/手順)")
    priority: int = Field(
        description="1 が最高優先。数値が小さいほど優先。明記が無い場合は 0 (後段で出典行順に自動採番)。"
    )
    source: SourceRef
    notes: Optional[str] = None


class SheetExtraction(StrictModel):
    """VLM がシート 1 枚から出力する単位。"""

    sheet_name: str
    rules: list[BusinessRule]
    cross_references: list[str] = Field(
        default_factory=list, description="「別表参照」「別紙 X」等、シート間参照の記述"
    )
    unparsed_notes: list[str] = Field(
        default_factory=list, description="スキーマに落とせなかった注記・判読不能箇所"
    )


class Conflict(StrictModel):
    kind: Literal[
        "same_condition_diff_action",  # 条件シグネチャ同一でアクションが異なる
        "priority_mixed",              # 同一シートで優先度の明記/未明記が混在
        "duplicate_rule",              # 完全重複
        "semantic_overlap",            # LLM スキャンで検出した意味的な重なり
        "other",
    ]
    rule_ids: list[str]
    detail: str


class ConflictScan(StrictModel):
    """LLM による意味的コンフリクトスキャンの出力ラッパ。"""

    conflicts: list[Conflict]


class Rulebook(StrictModel):
    version: str
    source_file: str
    rules: list[BusinessRule]
    conflicts: list[Conflict] = Field(default_factory=list)
    cross_references: list[str] = Field(default_factory=list)
    unparsed_notes: list[str] = Field(default_factory=list)

    def rule_ids(self) -> set[str]:
        return {r.rule_id for r in self.rules}

    def by_id(self, rid: str) -> Optional[BusinessRule]:
        for r in self.rules:
            if r.rule_id == rid:
                return r
        return None


class CardFields(StrictModel):
    """名刺画像から VLM が抽出するフィールド。印字のまま (正規化はコード側)。"""

    company: Optional[str] = None
    department: Optional[str] = None
    title: Optional[str] = None
    person_name: Optional[str] = None
    email: Optional[str] = None
    phone: Optional[str] = None
    address: Optional[str] = None
    other_text: list[str] = Field(
        default_factory=list, description="上記に該当しない印字テキスト (裏面/英語面など)"
    )


class JudgeVerdict(StrictModel):
    applicable_rules: list[str] = Field(
        description="例外除外後に適用可能と判断した全 rule_id"
    )
    selected_rule: Optional[str] = Field(
        default=None, description="priority 解決後の採用ルール。abstain 時は null。"
    )
    abstain: bool = Field(description="該当なし/同順位競合/情報不足なら true")
    confidence: Literal["high", "medium", "low"]
    rationale: str


class RouteDecision(StrictModel):
    """パイプラインの最終出力 (1 名刺分)。"""

    card: str
    selected_rule: Optional[str]
    action: Optional[str]
    abstain: bool
    confidence: Literal["high", "medium", "low"]
    decided_by: Literal["engine", "judge", "engine+judge"]
    applicable_rules: list[str] = Field(default_factory=list)
    rationale: str = ""
    fields: CardFields
