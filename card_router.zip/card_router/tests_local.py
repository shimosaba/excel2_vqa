"""ネットワーク (vLLM サーバ) 不要のローカルテスト。python3 tests_local.py で実行。"""
from __future__ import annotations

from judge import sanitize_verdict
from merge_rules import merge
from normalize import normalize_card_fields, normalize_text
from rule_engine import Tri, route, rule_applicability
from schemas import (
    BusinessRule,
    CardFields,
    JudgeVerdict,
    RuleCondition,
    Rulebook,
    SheetExtraction,
    SourceRef,
)

def R(rid, prio, when_all=(), when_any=(), exceptions=(), action="act"):
    return BusinessRule(
        rule_id=rid, name=rid, when_all=list(when_all), when_any=list(when_any),
        exceptions=list(exceptions), action=action, priority=prio,
        source=SourceRef(sheet="s", cell_range="A1:B2"),
    )


def C(field, op, *values):
    return RuleCondition(field=field, op=op, values=list(values))


def test_normalize():
    assert normalize_text("㈱テック  ラボ") == normalize_text("株式会社テックラボ")
    assert normalize_text("ＡＢＣ Corp") == "abccorp"
    f = normalize_card_fields(CardFields(company="(株)Ｅｘａｍｐｌｅ", email="Ken@R.Example.JP "))
    assert f["company"] == "株式会社example"
    assert f["email_domain"] == "r.example.jp"


def test_engine_tri():
    fields = normalize_card_fields(
        CardFields(company="株式会社テック", department="研究開発部", title="部長")
    )
    # MATCH
    r1 = R("R1", 10, when_all=[C("company", "contains", "テック"), C("title", "equals", "部長")])
    assert rule_applicability(r1, fields) == Tri.TRUE
    # exception で除外 → FALSE
    r2 = R("R2", 10, when_all=[C("company", "contains", "テック")],
           exceptions=[C("department", "contains", "研究")])
    assert rule_applicability(r2, fields) == Tri.FALSE
    # semantic → UNKNOWN
    r3 = R("R3", 10, when_all=[C("department", "semantic", "研究職に見える部署")])
    assert rule_applicability(r3, fields) == Tri.UNKNOWN
    # 対象フィールド空 → UNKNOWN (not_contains でも不在を確認できない)
    empty = normalize_card_fields(CardFields(company="株式会社テック"))
    r4 = R("R4", 10, when_all=[C("department", "not_contains", "営業")])
    assert rule_applicability(r4, empty) == Tri.UNKNOWN
    # when_any: 1 つ TRUE で成立
    r5 = R("R5", 10, when_any=[C("title", "equals", "課長"), C("title", "equals", "部長")])
    assert rule_applicability(r5, fields) == Tri.TRUE
    # regex
    r6 = R("R6", 10, when_all=[C("email_domain", "regex", r"\.ac\.jp$")])
    ac = normalize_card_fields(CardFields(email="x@dept.tohoku.ac.jp"))
    assert rule_applicability(r6, ac) == Tri.TRUE


def test_engine_route():
    fields = normalize_card_fields(CardFields(company="株式会社テック", title="部長"))
    rb = Rulebook(version="t", source_file="t", rules=[
        R("A", 10, when_all=[C("company", "contains", "テック")], action="ルートA"),
        R("B", 20, when_all=[C("title", "equals", "部長")], action="ルートB"),
    ])
    er = route(rb, fields)
    assert er.decided and er.selected.rule_id == "A" and set(er.applicable) == {"A", "B"}

    # 同順位・異アクション → tie
    rb2 = Rulebook(version="t", source_file="t", rules=[
        R("A", 10, when_all=[C("company", "contains", "テック")], action="ルートA"),
        R("B", 10, when_all=[C("title", "equals", "部長")], action="ルートB"),
    ])
    er2 = route(rb2, fields)
    assert not er2.decided and er2.tie and {r.rule_id for r in er2.candidates} == {"A", "B"}

    # UNKNOWN が勝者より低優先 → judge 不要で決定できる (blocking 最適化)
    rb3 = Rulebook(version="t", source_file="t", rules=[
        R("A", 10, when_all=[C("company", "contains", "テック")], action="ルートA"),
        R("S", 50, when_all=[C("department", "semantic", "研究系")], action="ルートS"),
    ])
    er3 = route(rb3, fields)
    assert er3.decided and er3.selected.rule_id == "A"

    # UNKNOWN が勝者と同順位以上 → judge へ
    rb4 = Rulebook(version="t", source_file="t", rules=[
        R("A", 10, when_all=[C("company", "contains", "テック")], action="ルートA"),
        R("S", 5, when_all=[C("title", "semantic", "役員クラス")], action="ルートS"),
    ])
    er4 = route(rb4, fields)
    assert not er4.decided and {r.rule_id for r in er4.candidates} == {"A", "S"}

    # 全く該当なし
    er5 = route(rb, normalize_card_fields(CardFields(company="株式会社別会社")))
    # rb の B は title 条件 → title 空で UNKNOWN 扱いになるため candidates に入る
    assert not er5.decided and not er5.no_match

    er6 = route(
        Rulebook(version="t", source_file="t",
                 rules=[R("A", 10, when_all=[C("company", "equals", "無関係")])]),
        normalize_card_fields(CardFields(company="株式会社テック")),
    )
    assert er6.no_match


def test_merge():
    e1 = SheetExtraction(sheet_name="教授対応", rules=[
        R("R1", 10, when_all=[C("title", "equals", "教授")], action="ルートA"),
        R("R2", 20, when_all=[C("company", "contains", "テック")], action="ルートB"),
    ])
    e2 = SheetExtraction(sheet_name="別表", rules=[
        R("R1", 10, when_all=[C("title", "equals", "教授")], action="ルートA"),   # 完全重複
        R("R2", 30, when_all=[C("company", "contains", "テック")], action="ルートC"),  # 同条件・異アクション
    ], cross_references=["詳細は運用メモ参照"])
    rb = merge([e1, e2], "test.xlsx")
    ids = rb.rule_ids()
    assert "S01-R1" in ids and "S02-R1" not in ids  # 重複は代表のみ
    kinds = {c.kind for c in rb.conflicts}
    assert kinds == {"duplicate_rule", "same_condition_diff_action"}
    assert any("別表" in x for x in rb.cross_references)
    assert rb.by_id("S01-R2").action == "ルートB" and rb.by_id("S02-R2").action == "ルートC"


def test_schemas_guided():
    from schemas import CardFields, JudgeVerdict, SheetExtraction
    for m in (SheetExtraction, CardFields, JudgeVerdict):
        s = m.model_json_schema()
        assert s.get("additionalProperties") is False, m.__name__


def test_sanitize():
    rules = [R("A", 10), R("B", 20)]
    v = JudgeVerdict(applicable_rules=["A", "GHOST"], selected_rule="GHOST",
                     abstain=False, confidence="high", rationale="x")
    v2 = sanitize_verdict(v, rules)
    assert v2.applicable_rules == ["A"] and v2.selected_rule is None and v2.abstain

    v3 = sanitize_verdict(JudgeVerdict(applicable_rules=["A"], selected_rule="A",
                                       abstain=False, confidence="high", rationale="x"), rules)
    assert v3.selected_rule == "A" and not v3.abstain




def test_plan_bands():
    from excel_render import plan_bands
    # 小さいシートは単一バンド
    assert plan_bands(120, band_rows=150, overlap=20) == [(1, 120)]
    bands = plan_bands(1000, band_rows=150, overlap=20)
    assert bands[0] == (1, 150) and bands[1] == (131, 280)
    assert bands[-1][1] == 1000
    # 全行がいずれかのバンドに含まれ、隣接バンドが重なる
    covered = set()
    for a, b in bands:
        covered.update(range(a, b + 1))
    assert covered == set(range(1, 1001))
    for (a1, b1), (a2, b2) in zip(bands, bands[1:]):
        assert a2 <= b1  # overlap


def test_row_offsets_hidden_custom():
    from openpyxl import Workbook
    from excel_render import row_offsets
    wb = Workbook(); ws = wb.active
    for r in range(1, 11):
        ws.cell(row=r, column=1, value=r)
    ws.row_dimensions[3].height = 30.0
    ws.row_dimensions[5].hidden = True
    offs = row_offsets(ws, 10)
    default = offs[1] - offs[0]
    assert abs((offs[3] - offs[2]) - 30.0) < 1e-6      # カスタム行高
    assert abs(offs[5] - offs[4]) < 1e-9               # 非表示行 = 高さ0
    assert abs((offs[10] - offs[9]) - default) < 1e-6


def test_grid_band_slice():
    from openpyxl import Workbook
    from excel_render import sheet_grid_text
    wb = Workbook(); ws = wb.active
    ws["A1"] = "ヘッダA"; ws["B1"] = "ヘッダB"
    for r in range(2, 401):
        ws.cell(row=r, column=1, value=f"値{r}")
    ws.row_dimensions[350].hidden = True
    ws.merge_cells("A300:B301")
    g = sheet_grid_text(ws, 300, 360, header_rows=1)
    assert "ヘッダ行 1〜1 (再掲)" in g and "ヘッダA" in g
    assert "\n300\t" in g and "値360" in g and "値299" not in g
    assert "350[非表示]" in g
    assert "A300:B301" in g


def test_drawings_parse():
    from xml.etree import ElementTree as ET
    from drawings import _parse_drawing_root
    xml = """<xdr:wsDr xmlns:xdr="http://schemas.openxmlformats.org/drawingml/2006/spreadsheetDrawing"
      xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main"
      xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"
      xmlns:mc="http://schemas.openxmlformats.org/markup-compatibility/2006">
      <xdr:twoCellAnchor>
        <xdr:from><xdr:col>4</xdr:col><xdr:colOff>0</xdr:colOff><xdr:row>309</xdr:row><xdr:rowOff>0</xdr:rowOff></xdr:from>
        <xdr:to><xdr:col>7</xdr:col><xdr:colOff>0</xdr:colOff><xdr:row>314</xdr:row><xdr:rowOff>0</xdr:rowOff></xdr:to>
        <xdr:sp><xdr:nvSpPr><xdr:cNvPr id="9" name="TextBox 9"/><xdr:cNvSpPr txBox="1"/></xdr:nvSpPr>
          <xdr:spPr/><xdr:txBody><a:bodyPr/>
          <a:p><a:r><a:t>ただし役員名刺は</a:t></a:r><a:r><a:t>総務経由とする</a:t></a:r></a:p>
          <a:p><a:r><a:t>2行目</a:t></a:r></a:p></xdr:txBody></xdr:sp>
        <xdr:clientData/>
      </xdr:twoCellAnchor>
      <xdr:oneCellAnchor>
        <xdr:from><xdr:col>1</xdr:col><xdr:colOff>0</xdr:colOff><xdr:row>99</xdr:row><xdr:rowOff>0</xdr:rowOff></xdr:from>
        <xdr:ext cx="1" cy="1"/>
        <xdr:grpSp><xdr:sp><xdr:nvSpPr><xdr:cNvPr id="10" name="G1"/></xdr:nvSpPr>
          <xdr:txBody><a:p><a:r><a:t>グループ内図形</a:t></a:r></a:p></xdr:txBody></xdr:sp>
          <xdr:pic><xdr:nvPicPr><xdr:cNvPr id="11" name="Pic1"/></xdr:nvPicPr>
            <xdr:blipFill><a:blip r:embed="rId7"/></xdr:blipFill></xdr:pic>
        </xdr:grpSp>
        <xdr:clientData/>
      </xdr:oneCellAnchor>
      <xdr:twoCellAnchor>
        <xdr:from><xdr:col>0</xdr:col><xdr:colOff>0</xdr:colOff><xdr:row>10</xdr:row><xdr:rowOff>0</xdr:rowOff></xdr:from>
        <xdr:to><xdr:col>3</xdr:col><xdr:colOff>0</xdr:colOff><xdr:row>20</xdr:row><xdr:rowOff>0</xdr:rowOff></xdr:to>
        <mc:AlternateContent>
          <mc:Choice Requires="x"><xdr:sp><xdr:nvSpPr><xdr:cNvPr id="12" name="New"/></xdr:nvSpPr>
            <xdr:txBody><a:p><a:r><a:t>Choice側テキスト</a:t></a:r></a:p></xdr:txBody></xdr:sp></mc:Choice>
          <mc:Fallback><xdr:sp><xdr:nvSpPr><xdr:cNvPr id="13" name="Old"/></xdr:nvSpPr>
            <xdr:txBody><a:p><a:r><a:t>Fallback側テキスト</a:t></a:r></a:p></xdr:txBody></xdr:sp></mc:Fallback>
        </mc:AlternateContent>
        <xdr:clientData/>
      </xdr:twoCellAnchor>
      <xdr:twoCellAnchor>
        <xdr:from><xdr:col>0</xdr:col><xdr:colOff>0</xdr:colOff><xdr:row>50</xdr:row><xdr:rowOff>0</xdr:rowOff></xdr:from>
        <xdr:to><xdr:col>5</xdr:col><xdr:colOff>0</xdr:colOff><xdr:row>70</xdr:row><xdr:rowOff>0</xdr:rowOff></xdr:to>
        <xdr:graphicFrame><xdr:nvGraphicFramePr><xdr:cNvPr id="14" name="Chart1"/></xdr:nvGraphicFramePr></xdr:graphicFrame>
        <xdr:clientData/>
      </xdr:twoCellAnchor>
    </xdr:wsDr>"""
    shapes, pics, charts = _parse_drawing_root(ET.fromstring(xml), {"rId7": "xl/media/image1.png"})
    texts = {s.text for s in shapes}
    assert "ただし役員名刺は総務経由とする\n2行目" in texts
    assert "グループ内図形" in texts
    assert "Choice側テキスト" in texts and "Fallback側テキスト" not in texts
    tb = next(s for s in shapes if "役員" in s.text)
    assert tb.row == 310 and tb.row_to == 315 and tb.col == 5
    assert pics == [(100, None, 2, "Pic1", "xl/media/image1.png", True)]
    assert charts == [51]


def test_sentinel_priorities():
    e1 = SheetExtraction(sheet_name="全部未明記", rules=[
        R("R1", 0, when_all=[C("title", "equals", "教授")], action="A"),
        R("R2", 0, when_all=[C("title", "equals", "助教")], action="B"),
    ])
    e1.rules[0].source.cell_range = "B40:D40"
    e1.rules[1].source.cell_range = "B12:D12"
    e2 = SheetExtraction(sheet_name="混在", rules=[
        R("R1", 5, when_all=[C("company", "contains", "X")], action="A"),
        R("R2", 0, when_all=[C("company", "contains", "Y")], action="B"),
    ])
    e2.rules[0].source.cell_range = "A2"
    e2.rules[1].source.cell_range = "A9"
    rb = merge([e1, e2], "t.xlsx")
    # 全部未明記: 行順 (R2=行12 が先) に 10, 20
    assert rb.by_id("S01-R2").priority == 10 and rb.by_id("S01-R1").priority == 20
    # 混在: 明記(5)の後ろに採番 + priority_mixed conflict
    assert rb.by_id("S02-R1").priority == 5 and rb.by_id("S02-R2").priority == 15
    assert any(c.kind == "priority_mixed" for c in rb.conflicts)
    # 0 のまま残るルールが無い (0 は「1より高優先」に化けるため)
    assert all(r.priority > 0 for r in rb.rules)


if __name__ == "__main__":
    import sys
    mod = sys.modules[__name__]
    fns = [f for n, f in vars(mod).items() if n.startswith("test_")]
    for fn in fns:
        fn()
        print(f"OK  {fn.__name__}")
    print(f"\n{len(fns)} tests passed")
