"""評価: results.jsonl × labels.csv → 指標 + risk-coverage 曲線。

labels.csv 形式 (ヘッダあり):
  card,gold
  cards/0001.jpg,S01-R3
  cards/0002.jpg,REJECT      # どのルールにも該当しない (abstain が正解)

指標:
- coverage      = 回答率 (1 - abstain 率)
- risk          = 回答したものの誤り率 (selective risk)
- top1_accuracy = 回答したもののうち gold と一致した割合 (= 1 - risk)
- reject_recall = gold=REJECT のうち abstain できた割合
- confidence 閾値 (high のみ回答 / high+medium / 全回答) を掃引して risk-coverage 曲線を出力。
  OCR 選択的予測で使った枠組みと同じ読み方ができる。
"""
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

CONF_ORDER = {"high": 2, "medium": 1, "low": 0}


def load_results(path: str) -> dict[str, dict]:
    out = {}
    with open(path, encoding="utf-8") as f:
        for line in f:
            if line.strip():
                d = json.loads(line)
                out[Path(d["card"]).name] = d
    return out


def load_labels(path: str) -> dict[str, str]:
    out = {}
    with open(path, encoding="utf-8") as f:
        for row in csv.DictReader(f):
            out[Path(row["card"]).name] = row["gold"].strip()
    return out


def eval_at_threshold(pairs: list[tuple[dict, str]], min_conf: int) -> dict:
    """min_conf 以上の confidence のみ回答扱い。gold=REJECT は abstain が正解。"""
    answered = correct = 0
    n = len(pairs)
    reject_total = reject_ok = 0
    for res, gold in pairs:
        conf_ok = CONF_ORDER.get(res.get("confidence", "low"), 0) >= min_conf
        answers = (not res.get("abstain", False)) and conf_ok
        if gold == "REJECT":
            reject_total += 1
            if not answers:
                reject_ok += 1
            else:
                answered += 1  # REJECT すべきものに回答 = 誤答
            continue
        if answers:
            answered += 1
            if res.get("selected_rule") == gold:
                correct += 1
    coverage = answered / n if n else 0.0
    risk = 1 - correct / answered if answered else 0.0
    return {
        "coverage": coverage,
        "risk": risk,
        "top1_accuracy_on_answered": 1 - risk if answered else None,
        "answered": answered,
        "n": n,
        "reject_recall": (reject_ok / reject_total) if reject_total else None,
    }


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("results", help="route-batch の出力 JSONL")
    ap.add_argument("labels", help="labels.csv (card,gold)")
    ap.add_argument("-o", "--outdir", default="eval_out")
    args = ap.parse_args()

    results = load_results(args.results)
    labels = load_labels(args.labels)
    pairs = [(results[k], g) for k, g in labels.items() if k in results]
    missing = [k for k in labels if k not in results]
    if missing:
        print(f"[warn] results に無いラベル {len(missing)} 件をスキップ: {missing[:5]} ...")

    outdir = Path(args.outdir)
    outdir.mkdir(parents=True, exist_ok=True)

    points = []
    for name, min_conf in (("high_only", 2), ("high+medium", 1), ("all_answered", 0)):
        m = eval_at_threshold(pairs, min_conf)
        m["threshold"] = name
        points.append(m)
        print(
            f"{name:12s} coverage={m['coverage']:.3f} risk={m['risk']:.3f} "
            f"answered={m['answered']}/{m['n']} reject_recall={m['reject_recall']}"
        )

    per_decider: dict[str, list[int]] = {}
    for res, gold in pairs:
        d = res.get("decided_by", "?")
        ok = (gold == "REJECT" and res.get("abstain")) or (
            gold != "REJECT" and not res.get("abstain") and res.get("selected_rule") == gold
        )
        per_decider.setdefault(d, []).append(int(ok))
    decider_acc = {k: sum(v) / len(v) for k, v in per_decider.items()}
    print("decided_by 別正解率:", {k: f"{v:.3f} (n={len(per_decider[k])})" for k, v in decider_acc.items()})

    (outdir / "metrics.json").write_text(
        json.dumps({"points": points, "decider_accuracy": decider_acc}, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )

    try:
        import matplotlib

        matplotlib.use("Agg")
        import matplotlib.pyplot as plt

        xs = [p["coverage"] for p in points]
        ys = [p["risk"] for p in points]
        fig, ax = plt.subplots(figsize=(5, 4))
        ax.plot(xs, ys, "o-")
        for p in points:
            ax.annotate(p["threshold"], (p["coverage"], p["risk"]), fontsize=8,
                        xytext=(4, 4), textcoords="offset points")
        ax.set_xlabel("coverage")
        ax.set_ylabel("selective risk")
        ax.set_title("Risk-Coverage (confidence threshold sweep)")
        ax.grid(alpha=0.3)
        fig.tight_layout()
        fig.savefig(outdir / "risk_coverage.png", dpi=150)
        print(f"[done] -> {outdir}/metrics.json, risk_coverage.png")
    except ImportError:
        print(f"[done] -> {outdir}/metrics.json (matplotlib 無しのためプロット省略)")


if __name__ == "__main__":
    main()
