#!/usr/bin/env bash
# Qwen3.5-27B (ネイティブVL, dense 27B, GDN+Gated Attention ハイブリッド) を vLLM で起動。
# 要 vLLM 最新安定版: uv pip install -U vllm --torch-backend=auto
# (リリース直後は nightly 必須だったが、現行安定版で対応済み)
set -euo pipefail

MODEL="${MODEL:-Qwen/Qwen3.5-27B}"
PORT="${PORT:-8000}"
MAX_LEN="${MAX_LEN:-65536}"   # 本パイプラインの実ワークロードには十分。thinking を多用するなら 131072 に

# ---- H100 / H200 (80GB+) 1 枚: BF16 ----
# 27B BF16 ≈ 56GB 重み。GDN 層は KV ではなく固定サイズの状態キャッシュなので
# full-attention 系よりキャッシュメモリは軽い。
exec vllm serve "$MODEL" \
  --port "$PORT" \
  --max-model-len "$MAX_LEN" \
  --reasoning-parser qwen3 \
  --enable-prefix-caching \
  --gpu-memory-utilization 0.90

# ================= 備考 (必要に応じて上を書き換え) =================
#
# [thinking]
#   Qwen3.5 はデフォルト thinking ON。本パイプラインはリクエスト側で
#   chat_template_kwargs {"enable_thinking": false} を送るのでサーバはこのままで良い。
#   サーバ側で一括無効化したい場合:
#     --default-chat-template-kwargs '{"enable_thinking": false}'
#   thinking を使う場合も --reasoning-parser qwen3 は必須
#   (構造化出力の文法制約を最終回答チャネルのみに適用させるため)。
#
# [prefix caching]
#   judge はルールブックを system に置くため名刺間で長い共有プレフィックスができ、
#   prefix caching が効く。ただし GDN/Mamba 系の align モードは実験的扱いで、
#   ハイブリッドキャッシュのブロックサイズが大きく (~2048) 短いプレフィックスは
#   キャッシュされない点に注意 (ルールブックが長ければ実害なし)。
#   問題が出たら --no-enable-prefix-caching で切って比較する。
#
# [L40S 48GB]
#   BF16 は載らない。FP8 チェックポイント (Qwen 公式が各サイズで公開している
#   -FP8 版。無ければ llm-compressor で W8A8-FP8 化) を使う:
#     MODEL=Qwen/Qwen3.5-27B-FP8 MAX_LEN=32768 ./serve_vllm.sh
#   もしくは L40S ×2 で BF16 + TP2: --tensor-parallel-size 2
#
# [A100 80GB]
#   FP8 (W8A8) はネイティブ非対応 (Ada/Hopper 以降)。BF16 のまま 1 枚で可。
#
# [MTP 投機デコード]
#   低同時実行のレイテンシ改善用。バッチ処理主体の本パイプラインでは
#   スループットを下げ得るので基本オフ。試す場合:
#     --speculative-config '{"method":"qwen3_next_mtp","num_speculative_tokens":2}'
#
# [既知のエラー]
#   causal_conv1d_update ... assert num_cache_lines >= batch
#   → CUDA graph capture サイズ > mamba cache。--max-cudagraph-capture-size を下げる。
#
# [マルチ GPU でビジョン重視のスループットを稼ぐ場合]
#   --mm-encoder-tp-mode data --mm-processor-cache-type shm
