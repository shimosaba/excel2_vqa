"""名刺画像 → CardFields (構造化フィールド抽出)。プローズ説明は作らない。"""
from __future__ import annotations

from pathlib import Path

from openai import AsyncOpenAI

from config import settings
from schemas import CardFields
from vlm_client import image_part, image_to_data_url, structured_chat, text_part

SYSTEM_PROMPT = """あなたは名刺情報抽出器です。入力は名刺画像 (表面のみ、または表裏)。
出力は指定スキーマに準拠した JSON のみです。

方針:
- 印字されている文字列をそのまま転記する (表記の正規化・翻訳・補完はしない)。
- 会社ロゴ等からの推測で company を埋めない。印字が読めない場合は null。
- 部署と役職が連結して印字されている場合は分割する (例: 「開発部 部長」→ department/title)。
- 該当フィールドの印字が無ければ null。
- 上記フィールドに該当しない印字 (キャッチコピー、資格、裏面の英語表記など) は
  other_text に入れる。"""


async def extract_card(client: AsyncOpenAI, image_paths: list[Path]) -> CardFields:
    content = [text_part("この名刺から情報を抽出してください。")]
    for p in image_paths:
        content.append(
            image_part(image_to_data_url(p, settings.image_long_side_card, fmt="JPEG"))
        )
    messages = [
        {"role": "system", "content": SYSTEM_PROMPT},
        {"role": "user", "content": content},
    ]
    return await structured_chat(
        client, messages, CardFields, max_tokens=settings.max_tokens_card, think=False
    )
