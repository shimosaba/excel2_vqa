"""パイプライン共通設定。環境変数で上書き可能。"""
import os
from dataclasses import dataclass


def _env_int(key: str, default: int) -> int:
    return int(os.environ.get(key, default))


@dataclass
class Settings:
    base_url: str = os.environ.get("VLLM_BASE_URL", "http://localhost:8000/v1")
    api_key: str = os.environ.get("VLLM_API_KEY", "EMPTY")
    model: str = os.environ.get("CARD_ROUTER_MODEL", "Qwen/Qwen3.5-27B")

    # --- サンプリング方針 ---
    # Qwen3.5 公式推奨 (non-thinking: temp=0.7 / top_p=0.8 / presence_penalty=1.5) は
    # チャット用途向け。presence_penalty は JSON 内で反復するトークン
    # (キー名, 区切り記号, 同一企業名の再出現など) を歪めるため、構造化抽出では 0 に固定し、
    # 決定性優先で temperature=0 とする。
    temperature: float = float(os.environ.get("CARD_ROUTER_TEMPERATURE", "0.0"))

    # thinking モード (judge の精度を上げたい場合のみ)。Qwen3.5 はデフォルト thinking ON なので
    # 通常リクエストでは chat_template_kwargs で明示的に無効化する。
    # thinking 有効時は公式推奨の thinking 用サンプリングに切り替える。
    enable_thinking_judge: bool = os.environ.get("CARD_ROUTER_JUDGE_THINK", "0") == "1"
    thinking_temperature: float = 1.0
    thinking_top_p: float = 0.95
    thinking_top_k: int = 20

    max_tokens_extract: int = _env_int("CARD_ROUTER_MAX_TOKENS_EXTRACT", 8192)
    max_tokens_card: int = _env_int("CARD_ROUTER_MAX_TOKENS_CARD", 1536)
    max_tokens_judge: int = _env_int("CARD_ROUTER_MAX_TOKENS_JUDGE", 2048)
    # thinking 有効時は思考トークン分の余裕が必要
    max_tokens_judge_thinking: int = _env_int("CARD_ROUTER_MAX_TOKENS_JUDGE_THINK", 16384)

    concurrency: int = _env_int("CARD_ROUTER_CONCURRENCY", 8)
    request_timeout: float = float(os.environ.get("CARD_ROUTER_TIMEOUT", "600"))

    # --- 画像まわり ---
    # 名刺はクライアント側で長辺を制限してビジョントークン量を決定的に制御する。
    image_long_side_card: int = _env_int("CARD_ROUTER_IMG_CARD", 1280)

    # --- バンド処理 (1000行超シート・図形多数対応) ---
    band_rows: int = _env_int("CARD_ROUTER_BAND_ROWS", 150)          # 1バンドの行数
    band_overlap: int = _env_int("CARD_ROUTER_BAND_OVERLAP", 20)     # 前バンドとの重なり行数
    header_rows: int = _env_int("CARD_ROUTER_HEADER_ROWS", 4)        # 毎バンド再掲するヘッダ行数
    target_px_per_row: int = _env_int("CARD_ROUTER_PX_PER_ROW", 32)  # 領域レンダの目標px/行 (24〜45)
    dpi_min: int = 72
    dpi_max: int = 600
    band_img_max_width: int = _env_int("CARD_ROUTER_BAND_MAX_W", 2400)  # バンド画像の最大幅px
    figure_min_long_side: int = _env_int("CARD_ROUTER_FIGURE_MIN_PX", 480)  # これ以上はfigureパス
    max_band_images: int = _env_int("CARD_ROUTER_MAX_BAND_IMGS", 4)  # バンドに添付する小画像上限
    figure_ctx_rows: int = _env_int("CARD_ROUTER_FIGURE_CTX_ROWS", 4)  # figureに添える周辺グリッド行数

    # シートのセルグリッドテキスト上限 (文字数, バンド単位)。超過分は打ち切り注記を付ける。
    grid_char_limit: int = _env_int("CARD_ROUTER_GRID_CHAR_LIMIT", 24000)


settings = Settings()
