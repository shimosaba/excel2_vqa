"""LibreOffice 実機を使う統合テスト。python3 tests_integration.py で実行。

検証内容:
1. openpyxl で埋め込み画像入り 2 シート xlsx を生成し、zip 直編集でテキストボックスを注入
2. drawings.py が図形テキスト (アンカー行付き)・埋め込み画像 (寸法付き) を回収できる
3. build_render_context がシート↔ページ対応を確立できる
4. 非一様行高 (カスタム行高 + 非表示行) でも render_band の行→ピクセル写像が正しい
   (塗りつぶしマーカーの検出で判定)
"""
from __future__ import annotations

import re
import shutil
import sys
import zipfile
from pathlib import Path

from openpyxl import Workbook
from openpyxl.drawing.image import Image as XLImage
from openpyxl.styles import PatternFill
from PIL import Image, ImageDraw

from drawings import extract_drawings
from excel_render import build_render_context, plan_bands, render_band, row_offsets

WORK = Path("itest_work")

TEXTBOX_XML = (
    '<xdr:twoCellAnchor editAs="oneCell"'
    ' xmlns:xdr="http://schemas.openxmlformats.org/drawingml/2006/spreadsheetDrawing"'
    ' xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main">'
    "<xdr:from><xdr:col>4</xdr:col><xdr:colOff>0</xdr:colOff>"
    "<xdr:row>309</xdr:row><xdr:rowOff>0</xdr:rowOff></xdr:from>"
    "<xdr:to><xdr:col>7</xdr:col><xdr:colOff>0</xdr:colOff>"
    "<xdr:row>314</xdr:row><xdr:rowOff>0</xdr:rowOff></xdr:to>"
    '<xdr:sp><xdr:nvSpPr><xdr:cNvPr id="99" name="TextBox 99"/>'
    '<xdr:cNvSpPr txBox="1"/></xdr:nvSpPr><xdr:spPr/>'
    "<xdr:txBody><a:bodyPr/><a:p><a:r><a:t>ただし役員名刺は総務経由とする</a:t></a:r></a:p>"
    "</xdr:txBody></xdr:sp><xdr:clientData/></xdr:twoCellAnchor>"
)


def build_fixture(xlsx: Path) -> None:
    fig = WORK / "flow.png"
    im = Image.new("RGB", (640, 360), "white")
    d = ImageDraw.Draw(im)
    d.rectangle([10, 10, 630, 350], outline="black", width=3)
    d.line([60, 180, 580, 180], fill="blue", width=5)
    im.save(fig)

    wb = Workbook()
    ws = wb.active
    ws.title = "ルール大帳票"
    ws["A1"] = "役職"; ws["B1"] = "条件"; ws["C1"] = "処理"
    for r in range(2, 401):
        ws.cell(row=r, column=1, value=f"役職{r}")
        ws.cell(row=r, column=2, value=f"会社名に「KW{r}」を含む")
        ws.cell(row=r, column=3, value=f"ルート{r % 5}")
    for r in range(50, 60):
        ws.row_dimensions[r].height = 30.0  # カスタム行高
    for r in range(100, 103):
        ws.row_dimensions[r].hidden = True  # 非表示行
    ws["C333"].fill = PatternFill("solid", start_color="FFFFEE99")  # マーカー
    ws.add_image(XLImage(str(fig)), "C200")  # 埋め込み画像 (figure 閾値超)

    ws2 = wb.create_sheet("小シート")
    ws2["A1"] = "上記以外 → ルートZ"
    wb.save(xlsx)

    # テキストボックスを zip 直編集で注入 (openpyxl は図形を書けないため)
    src = zipfile.ZipFile(xlsx)
    items = {n: src.read(n) for n in src.namelist()}
    src.close()
    dxml = items["xl/drawings/drawing1.xml"].decode("utf-8")
    dxml2, n = re.subn(r"</(\w+:)?wsDr>", lambda m: TEXTBOX_XML + m.group(0), dxml, count=1)
    assert n == 1, "wsDr 閉じタグが見つからない"
    items["xl/drawings/drawing1.xml"] = dxml2.encode("utf-8")
    with zipfile.ZipFile(xlsx, "w", zipfile.ZIP_DEFLATED) as z:
        for name, data in items.items():
            z.writestr(name, data)


def count_yellow(path: Path) -> int:
    im = Image.open(path).convert("RGB")
    return sum(1 for r, g, b in im.getdata() if r > 230 and g > 215 and b < 190)


def main() -> None:
    if not (shutil.which("soffice") or shutil.which("libreoffice")):
        print("SKIP: soffice なし")
        return
    if WORK.exists():
        shutil.rmtree(WORK)
    WORK.mkdir()
    xlsx = WORK / "fixture.xlsx"
    build_fixture(xlsx)

    # --- drawings ---
    dw = extract_drawings(xlsx, WORK / "media")
    sd = dw["ルール大帳票"]
    tb = [s for s in sd.shapes if "役員名刺" in s.text]
    assert tb and tb[0].row == 310 and tb[0].row_to == 315, f"textbox: {sd.shapes}"
    assert len(sd.images) == 1, f"images: {sd.images}"
    img = sd.images[0]
    assert img.row == 200 and img.col == 3 and (img.width, img.height) == (640, 360), img
    assert max(img.width, img.height) >= 480  # figure パス対象
    assert dw["小シート"].shapes == [] and dw["小シート"].images == []
    print("OK  drawings: textbox row310-315 / image row200 640x360")

    # --- render context ---
    ctx = build_render_context(xlsx, WORK / "renders")
    assert list(ctx.pages) == ["ルール大帳票", "小シート"]
    assert ctx.pages["ルール大帳票"].page_index == 1
    print(f"OK  context: pages={[(p.sheet, round(p.height_pt,1)) for p in ctx.pages.values()]}")

    # --- band render + 写像精度 (非一様行高込み) ---
    from openpyxl import load_workbook
    wb = load_workbook(xlsx, data_only=True)
    ws = wb["ルール大帳票"]
    total = max(ws.max_row, sd.max_row())
    offs = row_offsets(ws, total)
    bands = plan_bands(total)
    print(f"    total_rows={total} bands={bands}")

    hit = render_band(ctx, "ルール大帳票", offs, 300, 360, WORK / "bands")
    miss = render_band(ctx, "ルール大帳票", offs, 150, 210, WORK / "bands")
    y_hit, y_miss = count_yellow(hit), count_yellow(miss)
    from PIL import Image as PILImage
    w, h = PILImage.open(hit).size
    px_per_row = h / 61
    print(f"    band(300-360): {w}x{h}px  px/行={px_per_row:.1f}  yellow={y_hit}")
    assert y_hit > 50, "マーカー行333がバンド(300-360)に入っていない"
    assert y_miss == 0, "バンド(150-210)にマーカーが混入 (写像ズレ)"
    assert 20 <= px_per_row <= 50, f"px/行が目標域外: {px_per_row}"
    print("OK  band render: 非一様行高でも写像正確・可読DPI")

    print("\nintegration tests passed")


if __name__ == "__main__":
    sys.exit(main())
