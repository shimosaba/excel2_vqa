"""LLM judge。

- ルールブック (または engine が絞った候補) を system メッセージに入れる。
  system を名刺間で同一に保つことで、vLLM の prefix caching (--enable-prefix-caching,
  GDN 系は Mamba cache align モード・実験的) が効き、共有プレフィックスの再計算を避けられる。
- 「適用可能な全ルールを列挙 → priority で解決 → 迷ったら abstain」を手順として強制する。
  margin は埋め込みスコア差ではなく、構造化出力の confidence + abstain で表現する。
"""
from __future__ import annotations

import json
from pathlib import Path

from openai import AsyncOpenAI

from config import settings
from schemas import BusinessRule, CardFields, JudgeVerdict, Rulebook
from vlm_client import image_part, image_to_data_url, structured_chat, text_part

SYSTEM_TEMPLATE = """あなたは名刺ルーティングの判定器です。与えられたルールブックに従い、
名刺 1 件に適用すべきルールを判定します。出力は指定スキーマの JSON のみです。

判定手順 (必ずこの順で):
1. 各ルールの when_all / when_any を名刺フィールドに照らし、適用可能な rule_id を
   すべて列挙する。exceptions のいずれかに該当するルールは除外する。
   → applicable_rules に列挙する (該当なしなら空リスト)。
2. applicable_rules のうち priority が最小 (= 最高優先) のルールを selected_rule とする。
3. 次のいずれかに該当する場合は abstain=true, selected_rule=null とする:
   - applicable_rules が空 (どのルールにも該当しない)
   - 最小 priority に複数ルールが並び、アクションが異なる
   - 判定に必要な情報が名刺に無い、または矛盾している
4. confidence:
   - high:   条件が名刺の印字と明示的に一致
   - medium: 表記ゆれ・略記・意味的解釈を要したが妥当
   - low:    かなり不確か (この場合 abstain も検討する)

制約:
- selected_rule は必ずルールブックに存在する rule_id、かつ applicable_rules の要素。
- ルールブックに書かれていない基準を持ち込まない。迷ったら abstain する。
- rationale は日本語で簡潔に (根拠となった条件と priority 解決を明示)。

=== ルールブック (JSON) ===
{rules_json}"""


def _rules_json(rules: list[BusinessRule]) -> str:
    return json.dumps(
        [r.model_dump(exclude_none=True) for r in rules],
        ensure_ascii=False,
        separators=(",", ":"),
    )


def build_system(rules: list[BusinessRule]) -> str:
    return SYSTEM_TEMPLATE.format(rules_json=_rules_json(rules))


async def judge_card(
    client: AsyncOpenAI,
    rules: list[BusinessRule],
    card: CardFields,
    normalized: dict[str, str],
    image_path: Path | None = None,
    engine_note: str = "",
) -> JudgeVerdict:
    user_content = [
        text_part(
            "=== 名刺フィールド (印字のまま) ===\n"
            + json.dumps(card.model_dump(exclude_none=True), ensure_ascii=False)
            + "\n\n=== 正規化済みフィールド (照合用) ===\n"
            + json.dumps({k: v for k, v in normalized.items() if v}, ensure_ascii=False)
            + (f"\n\n=== 決定的エンジンからの申し送り ===\n{engine_note}" if engine_note else "")
        )
    ]
    if image_path is not None:
        user_content.append(
            image_part(image_to_data_url(image_path, settings.image_long_side_card, fmt="JPEG"))
        )
    think = settings.enable_thinking_judge
    verdict = await structured_chat(
        client,
        [
            {"role": "system", "content": build_system(rules)},
            {"role": "user", "content": user_content},
        ],
        JudgeVerdict,
        max_tokens=settings.max_tokens_judge_thinking if think else settings.max_tokens_judge,
        think=think,
    )
    return sanitize_verdict(verdict, rules)


def sanitize_verdict(v: JudgeVerdict, rules: list[BusinessRule]) -> JudgeVerdict:
    """モデル出力の防御的検証: 存在しない rule_id を落とし、矛盾は abstain に倒す。"""
    known = {r.rule_id for r in rules}
    applicable = [rid for rid in v.applicable_rules if rid in known]
    selected = v.selected_rule
    abstain = v.abstain
    if selected is not None and (selected not in known or selected not in applicable):
        selected, abstain = None, True
    if abstain:
        selected = None
    if selected is None and not abstain:
        abstain = True
    return v.model_copy(
        update={"applicable_rules": applicable, "selected_rule": selected, "abstain": abstain}
    )
