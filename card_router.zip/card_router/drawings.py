"""xl/drawings 直読み (openpyxl 非依存)。

openpyxl は図形・テキストボックスを読まないため、xlsx (zip) から DrawingML を
直接パースし、「図形テキスト + アンカー行」「埋め込み画像 + アンカー行」を取り出す。
レンダリング縮小の影響を受けない、テキストとしての回収経路。

制約:
- mc:AlternateContent は Choice 側のみ辿る (Fallback は二重計上防止のためスキップ)。
- グラフ (graphicFrame) は内容をパースせず、アンカー行のみ記録 (本文はバンド画像で見せる)。
- absoluteAnchor (セル非依存の絶対配置) は行が確定しないため row=1・anchored=False で返す。
"""
from __future__ import annotations

import posixpath
import zipfile
from dataclasses import dataclass, field
from pathlib import Path
from xml.etree import ElementTree as ET

XDR = "{http://schemas.openxmlformats.org/drawingml/2006/spreadsheetDrawing}"
A = "{http://schemas.openxmlformats.org/drawingml/2006/main}"
MC = "{http://schemas.openxmlformats.org/markup-compatibility/2006}"
MAIN = "{http://schemas.openxmlformats.org/spreadsheetml/2006/main}"
R_ID = "{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id"
R_EMBED = "{http://schemas.openxmlformats.org/officeDocument/2006/relationships}embed"


@dataclass
class ShapeText:
    row: int                 # 1-based アンカー開始行
    row_to: int | None
    col: int
    kind: str                # "shape" | "connector"
    name: str
    text: str
    anchored: bool = True    # False = absoluteAnchor (行不明)


@dataclass
class EmbeddedImage:
    row: int
    row_to: int | None
    col: int
    name: str
    path: Path               # 展開先ファイル
    width: int
    height: int
    anchored: bool = True


@dataclass
class SheetDrawings:
    shapes: list[ShapeText] = field(default_factory=list)
    images: list[EmbeddedImage] = field(default_factory=list)
    chart_rows: list[int] = field(default_factory=list)

    def max_row(self) -> int:
        rows = [s.row_to or s.row for s in self.shapes if s.anchored]
        rows += [i.row_to or i.row for i in self.images if i.anchored]
        rows += self.chart_rows
        return max(rows, default=0)


def _local(tag: str) -> str:
    return tag.rsplit("}", 1)[-1]


def _rels(z: zipfile.ZipFile, part: str) -> dict[str, str]:
    """part の relationship を {rId: 正規化済みターゲットパス} で返す。"""
    d = posixpath.dirname(part)
    rels_path = posixpath.join(d, "_rels", posixpath.basename(part) + ".rels")
    if rels_path not in z.namelist():
        return {}
    out: dict[str, str] = {}
    for rel in ET.fromstring(z.read(rels_path)):
        rid, target = rel.get("Id"), rel.get("Target", "")
        if not rid or not target:
            continue
        if target.startswith("/"):
            out[rid] = target.lstrip("/")
        else:
            out[rid] = posixpath.normpath(posixpath.join(d, target))
    return out


def _visible_sheets(z: zipfile.ZipFile) -> list[tuple[str, str]]:
    """[(シート名, worksheet part パス)] を workbook 記載順 (可視のみ) で返す。"""
    root = ET.fromstring(z.read("xl/workbook.xml"))
    rels = _rels(z, "xl/workbook.xml")
    out = []
    sheets = root.find(MAIN + "sheets")
    if sheets is None:
        return out
    for sh in sheets:
        if sh.get("state", "visible") != "visible":
            continue
        part = rels.get(sh.get(R_ID, ""), "")
        if part:
            out.append((sh.get("name", ""), part))
    return out


def _anchor_pos(anchor) -> tuple[int, int | None, int, bool]:
    frm = anchor.find(XDR + "from")
    if frm is None:  # absoluteAnchor
        return 1, None, 1, False
    row = int(frm.findtext(XDR + "row", "0")) + 1
    col = int(frm.findtext(XDR + "col", "0")) + 1
    to = anchor.find(XDR + "to")
    row_to = int(to.findtext(XDR + "row", "0")) + 1 if to is not None else None
    return row, row_to, col, True


def _iter_drawables(elem):
    """anchor 配下の sp/cxnSp/pic/graphicFrame を列挙。grpSp は再帰、Fallback はスキップ。"""
    for child in elem:
        local = _local(child.tag)
        if local == "AlternateContent":
            node = child.find(MC + "Choice")
            if node is None:
                node = child.find(MC + "Fallback")
            if node is not None:
                yield from _iter_drawables(node)
        elif local in ("sp", "cxnSp", "pic", "graphicFrame"):
            yield local, child
        elif local == "grpSp":
            yield from _iter_drawables(child)


def _sp_text(sp) -> str:
    paras = []
    for p in sp.iter(A + "p"):
        t = "".join(r.text or "" for r in p.iter(A + "t"))
        if t.strip():
            paras.append(t.strip())
    return "\n".join(paras)


def _cnvpr_name(node) -> str:
    pr = node.find(f".//{XDR}cNvPr")
    return pr.get("name", "") if pr is not None else ""


def _parse_drawing_root(
    root, drels: dict[str, str]
) -> tuple[list[ShapeText], list[tuple[int, int | None, int, str, str, bool]], list[int]]:
    """drawing XML root をパース。

    Returns:
        shapes, pics [(row, row_to, col, name, media_part, anchored)], chart_rows
    """
    shapes: list[ShapeText] = []
    pics: list[tuple[int, int | None, int, str, str, bool]] = []
    chart_rows: list[int] = []

    top: list = []
    for child in root:
        if _local(child.tag) == "AlternateContent":
            node = child.find(MC + "Choice")
            if node is None:
                node = child.find(MC + "Fallback")
            top += list(node) if node is not None else []
        else:
            top.append(child)

    for anc in top:
        if _local(anc.tag) not in ("twoCellAnchor", "oneCellAnchor", "absoluteAnchor"):
            continue
        row, row_to, col, anchored = _anchor_pos(anc)
        for kind, node in _iter_drawables(anc):
            if kind in ("sp", "cxnSp"):
                text = _sp_text(node)
                if text:
                    shapes.append(
                        ShapeText(
                            row=row, row_to=row_to, col=col,
                            kind="shape" if kind == "sp" else "connector",
                            name=_cnvpr_name(node), text=text, anchored=anchored,
                        )
                    )
            elif kind == "graphicFrame":
                chart_rows.append(row)
            elif kind == "pic":
                blip = node.find(f".//{A}blip")
                rid = blip.get(R_EMBED) if blip is not None else None
                part = drels.get(rid or "", "")
                if part:
                    pics.append((row, row_to, col, _cnvpr_name(node), part, anchored))
    return shapes, pics, chart_rows


def extract_drawings(xlsx: Path, media_dir: Path) -> dict[str, SheetDrawings]:
    """{可視シート名: SheetDrawings}。埋め込み画像は media_dir に展開する。"""
    media_dir = Path(media_dir)
    media_dir.mkdir(parents=True, exist_ok=True)
    out: dict[str, SheetDrawings] = {}
    extracted: dict[str, Path] = {}  # media part -> 展開先 (再利用画像は1回だけ展開)

    with zipfile.ZipFile(xlsx) as z:
        names = set(z.namelist())
        for si, (sheet_name, sheet_part) in enumerate(_visible_sheets(z), start=1):
            sd = SheetDrawings()
            out[sheet_name] = sd
            if sheet_part not in names:
                continue
            sroot = ET.fromstring(z.read(sheet_part))
            drawing_el = sroot.find(MAIN + "drawing")
            if drawing_el is None:
                continue
            dpart = _rels(z, sheet_part).get(drawing_el.get(R_ID, ""), "")
            if not dpart or dpart not in names:
                continue
            drels = _rels(z, dpart)
            shapes, pics, chart_rows = _parse_drawing_root(ET.fromstring(z.read(dpart)), drels)
            sd.shapes = shapes
            sd.chart_rows = chart_rows
            for row, row_to, col, name, part, anchored in pics:
                if part not in names:
                    continue
                if part not in extracted:
                    dst = media_dir / f"s{si:02d}_{posixpath.basename(part)}"
                    dst.write_bytes(z.read(part))
                    extracted[part] = dst
                dst = extracted[part]
                try:
                    from PIL import Image

                    with Image.open(dst) as im:
                        w, h = im.size
                except Exception:
                    continue  # 破損/非対応フォーマットはスキップ
                sd.images.append(
                    EmbeddedImage(row=row, row_to=row_to, col=col, name=name,
                                  path=dst, width=w, height=h, anchored=anchored)
                )
    return out
