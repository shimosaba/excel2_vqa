"""CLI エントリポイント。

サブコマンド:
  build-rulebook  Excel → rulebook.json (+ conflicts はファイル内に格納)
  route           名刺 1 枚をルーティング
  route-batch     ディレクトリ内の名刺を一括ルーティング → JSONL

判定フロー (1 名刺):
  CardFields 抽出 → 正規化 → 決定的エンジン →
    decided     : そのまま採用 (decided_by=engine)
    tie         : engine が絞った勝者集合だけを judge へ (decided_by=engine+judge)
    それ以外    : 候補集合 (無ければルールブック全体) を judge へ (decided_by=judge)
"""
from __future__ import annotations

import argparse
import asyncio
import json
from pathlib import Path

from openai import AsyncOpenAI

from card_extract import extract_card
from config import settings
from extract_rules import extract_workbook
from judge import judge_card
from merge_rules import llm_conflict_scan, merge
from normalize import normalize_card_fields
from rule_engine import route as engine_route
from schemas import CardFields, Rulebook, RouteDecision
from vlm_client import make_client

CARD_EXTS = {".png", ".jpg", ".jpeg", ".webp", ".bmp"}


# ---------------------------------------------------------------- rulebook
async def cmd_build_rulebook(args) -> None:
    client = make_client()
    xlsx = Path(args.xlsx)
    workdir = Path(args.workdir)
    extractions = await extract_workbook(client, xlsx, workdir)
    rulebook = merge(extractions, source_file=xlsx.name)

    if args.conflict_scan:
        print("[merge] LLM コンフリクトスキャン ...", flush=True)
        rulebook.conflicts += await llm_conflict_scan(client, rulebook)

    out = Path(args.output)
    out.write_text(
        json.dumps(rulebook.model_dump(exclude_none=True), ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    print(f"[done] rules={len(rulebook.rules)} conflicts={len(rulebook.conflicts)} -> {out}")
    if rulebook.conflicts:
        print("=== 要人間レビュー ===")
        for c in rulebook.conflicts:
            print(f"- [{c.kind}] {', '.join(c.rule_ids)}: {c.detail}")
    if rulebook.cross_references:
        print("=== 未解決のシート間参照 ===")
        for x in rulebook.cross_references:
            print(f"- {x}")


# ---------------------------------------------------------------- routing
async def route_one(
    client: AsyncOpenAI,
    rulebook: Rulebook,
    card_path: Path,
    *,
    judge_image: bool = False,
    judge_on_no_match: bool = True,
) -> RouteDecision:
    card: CardFields = await extract_card(client, [card_path])
    fields = normalize_card_fields(card)
    er = engine_route(rulebook, fields)

    if er.decided:
        assert er.selected is not None
        return RouteDecision(
            card=str(card_path),
            selected_rule=er.selected.rule_id,
            action=er.selected.action,
            abstain=False,
            confidence="high",
            decided_by="engine",
            applicable_rules=er.applicable,
            rationale=er.rationale,
            fields=card,
        )

    if er.no_match and not judge_on_no_match:
        return RouteDecision(
            card=str(card_path),
            selected_rule=None,
            action=None,
            abstain=True,
            confidence="high",
            decided_by="engine",
            applicable_rules=[],
            rationale=er.rationale,
            fields=card,
        )

    # judge へ。tie のときは engine が絞った勝者集合のみを渡す (探索空間を狭める)。
    # それ以外は候補集合、no_match 時は抽出漏れの可能性を考慮しルールブック全体。
    candidates = er.candidates if er.candidates else rulebook.rules
    verdict = await judge_card(
        client,
        candidates,
        card,
        fields,
        image_path=card_path if judge_image else None,
        engine_note=er.rationale,
    )
    selected_rule = rulebook.by_id(verdict.selected_rule) if verdict.selected_rule else None
    return RouteDecision(
        card=str(card_path),
        selected_rule=verdict.selected_rule,
        action=selected_rule.action if selected_rule else None,
        abstain=verdict.abstain,
        confidence=verdict.confidence,
        decided_by="engine+judge" if er.tie else "judge",
        applicable_rules=sorted(set(er.applicable) | set(verdict.applicable_rules)),
        rationale=verdict.rationale,
        fields=card,
    )


def load_rulebook(path: str) -> Rulebook:
    return Rulebook.model_validate_json(Path(path).read_text(encoding="utf-8"))


async def cmd_route(args) -> None:
    client = make_client()
    rulebook = load_rulebook(args.rulebook)
    decision = await route_one(
        client,
        rulebook,
        Path(args.card),
        judge_image=args.judge_image,
        judge_on_no_match=not args.no_judge_on_no_match,
    )
    print(json.dumps(decision.model_dump(exclude_none=True), ensure_ascii=False, indent=2))


async def cmd_route_batch(args) -> None:
    client = make_client()
    rulebook = load_rulebook(args.rulebook)
    cards = sorted(
        p for p in Path(args.cards_dir).iterdir() if p.suffix.lower() in CARD_EXTS
    )
    if not cards:
        raise SystemExit(f"名刺画像が見つかりません: {args.cards_dir}")
    sem = asyncio.Semaphore(settings.concurrency)
    done = 0

    async def _one(p: Path) -> RouteDecision:
        nonlocal done
        async with sem:
            d = await route_one(
                client,
                rulebook,
                p,
                judge_image=args.judge_image,
                judge_on_no_match=not args.no_judge_on_no_match,
            )
            done += 1
            print(f"[{done}/{len(cards)}] {p.name} -> "
                  f"{d.selected_rule or 'ABSTAIN'} ({d.decided_by}/{d.confidence})", flush=True)
            return d

    decisions = await asyncio.gather(*[_one(p) for p in cards])
    with open(args.output, "w", encoding="utf-8") as f:
        for d in decisions:
            f.write(json.dumps(d.model_dump(exclude_none=True), ensure_ascii=False) + "\n")
    n_abstain = sum(d.abstain for d in decisions)
    n_engine = sum(d.decided_by == "engine" for d in decisions)
    print(
        f"[done] {len(decisions)} 件 / engine 決定 {n_engine} / abstain {n_abstain} -> {args.output}"
    )


# ---------------------------------------------------------------- main
def main() -> None:
    ap = argparse.ArgumentParser(description="名刺ルーティングパイプライン (Qwen3.5-27B / vLLM)")
    sub = ap.add_subparsers(dest="cmd", required=True)

    b = sub.add_parser("build-rulebook", help="Excel からルールブックを構築")
    b.add_argument("xlsx")
    b.add_argument("-o", "--output", default="rulebook.json")
    b.add_argument("--workdir", default="renders", help="シート画像の出力先")
    b.add_argument("--conflict-scan", action="store_true", help="LLM による意味的重複スキャンも実行")
    b.set_defaults(func=cmd_build_rulebook)

    r = sub.add_parser("route", help="名刺 1 枚をルーティング")
    r.add_argument("card")
    r.add_argument("--rulebook", required=True)
    r.add_argument("--judge-image", action="store_true", help="judge にも名刺画像を渡す")
    r.add_argument("--no-judge-on-no-match", action="store_true",
                   help="決定的に該当なしの場合 judge を呼ばず即 abstain")
    r.set_defaults(func=cmd_route)

    rb = sub.add_parser("route-batch", help="ディレクトリ内の名刺を一括ルーティング")
    rb.add_argument("cards_dir")
    rb.add_argument("--rulebook", required=True)
    rb.add_argument("-o", "--output", default="results.jsonl")
    rb.add_argument("--judge-image", action="store_true")
    rb.add_argument("--no-judge-on-no-match", action="store_true")
    rb.set_defaults(func=cmd_route_batch)

    args = ap.parse_args()
    asyncio.run(args.func(args))


if __name__ == "__main__":
    main()
