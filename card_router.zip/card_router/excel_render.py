"""Excel → (バンド領域レンダ画像, バンド別グリッドテキスト) 変換。

設計方針 (1000行超シート対応):
- 画像化は LibreOffice の PDF エクスポートを「元ファイルのまま」1 回だけ行う
  (openpyxl 再保存は図形・グラフが落ちるためしない)。
  Calc フィルタ SinglePageSheets=true (LO 7.4+) で 1 シート = 1 ページに固定。
  実測 (LO 24.2): ページ高さ 12,862.5pt を上限に全体が一様縮小される
  (クリップ無し・ベクタ保持) ため、必要な解像度はバンドごとの DPI で取り返す。
- バンド画像は pdftoppm の領域指定 (-x/-y/-W/-H) で直接切り出す。巨大 PNG を経由しない。
- 行→ページ内位置は行高の累積「比率」で写像する (一様縮小なので比率は保存される)。
  非表示行は印刷されないため高さ 0 として扱う。既定行高と LO の解釈差は
  band_overlap で吸収する。

制約 (README にも記載):
- 図形・テキストボックス内の文字はグリッドに出ない → drawings.py が XML 直読みで回収。
- 巨大シートでは横幅制約 (band_img_max_width) が DPI を律速し得る。
  px/行 が 16 を切る場合は警告を出す (横方向のタイル分割は未実装)。
- data_only=True は Excel 保存時の数式キャッシュ値前提。
- 日本語フォント (fonts-noto-cjk 等) がないと豆腐化する。
"""
from __future__ import annotations

import re
import shutil
import subprocess
import tempfile
from dataclasses import dataclass
from pathlib import Path

from openpyxl import load_workbook
from openpyxl.utils import get_column_letter

from config import settings

MAX_GRID_COLS = 64
MAX_COLOR_NOTES = 120
MAX_MERGED_NOTES = 200

_PDF_FILTER = 'pdf:calc_pdf_Export:{"SinglePageSheets":{"type":"boolean","value":true}}'
_PAGE_RE = re.compile(r"Page\s+(\d+)\s+size:\s+([\d.]+)\s+x\s+([\d.]+)\s+pts")


def _find_soffice() -> str:
    exe = shutil.which("soffice") or shutil.which("libreoffice")
    if not exe:
        raise RuntimeError(
            "LibreOffice (soffice) が見つかりません。libreoffice-calc をインストールしてください。"
        )
    return exe


def visible_sheet_names(xlsx: Path) -> list[str]:
    wb = load_workbook(xlsx, read_only=True)
    try:
        return [ws.title for ws in wb.worksheets if ws.sheet_state == "visible"]
    finally:
        wb.close()


def _safe_name(s: str) -> str:
    return "".join(c if c.isalnum() or c in "-_" else "_" for c in s) or "sheet"


# ---------------------------------------------------------------- render context
@dataclass
class SheetPage:
    sheet: str
    page_index: int      # PDF 内 1-based ページ番号
    width_pt: float
    height_pt: float


@dataclass
class RenderContext:
    pdf: Path
    pages: dict[str, SheetPage]  # 可視シート順


def build_render_context(xlsx: Path, workdir: Path) -> RenderContext:
    """ワークブック全体を 1 回だけ PDF 化し、シート↔ページ対応とページ寸法を確定する。"""
    xlsx = Path(xlsx).resolve()
    workdir = Path(workdir)
    workdir.mkdir(parents=True, exist_ok=True)
    soffice = _find_soffice()
    sheets = visible_sheet_names(xlsx)
    if not sheets:
        raise RuntimeError("可視シートがありません。")

    with tempfile.TemporaryDirectory() as prof:
        cmd = [
            soffice, "--headless", "--norestore",
            f"-env:UserInstallation=file://{prof}/lo_profile",
            "--convert-to", _PDF_FILTER,
            "--outdir", str(workdir), str(xlsx),
        ]
        proc = subprocess.run(cmd, capture_output=True, text=True, timeout=1200)
    pdf = workdir / (xlsx.stem + ".pdf")
    if proc.returncode != 0 or not pdf.exists():
        raise RuntimeError(
            f"LibreOffice PDF 変換に失敗: rc={proc.returncode}\n{proc.stderr[-2000:]}"
        )

    info = subprocess.run(
        ["pdfinfo", "-f", "1", "-l", str(len(sheets)), str(pdf)],
        check=True, capture_output=True, text=True, timeout=120,
    ).stdout
    sizes = {int(m[1]): (float(m[2]), float(m[3])) for m in _PAGE_RE.finditer(info)}
    if len(sizes) != len(sheets):
        raise RuntimeError(
            f"PDF ページ数 ({len(sizes)}) と可視シート数 ({len(sheets)}) が不一致。"
            "LibreOffice 7.4 未満で SinglePageSheets が無効の可能性があります。"
        )
    pages = {
        name: SheetPage(sheet=name, page_index=i, width_pt=sizes[i][0], height_pt=sizes[i][1])
        for i, name in enumerate(sheets, start=1)
    }
    return RenderContext(pdf=pdf, pages=pages)


# ---------------------------------------------------------------- 行→位置写像
def row_offsets(ws, total_rows: int) -> list[float]:
    """行高の累積オフセット (pt)。offs[r] = 行1..r の合計高。非表示行は 0。

    絶対値は LO のレイアウトと厳密一致しないが、写像は比率でのみ使うため
    一様縮小下で十分な精度になる (誤差は band_overlap で吸収)。
    """
    sf = ws.sheet_format
    default = float(sf.defaultRowHeight) if sf is not None and sf.defaultRowHeight else 13.5
    dims = ws.row_dimensions
    offs = [0.0]
    for r in range(1, total_rows + 1):
        rd = dims.get(r)
        if rd is not None and rd.hidden:
            h = 0.0
        elif rd is not None and rd.height is not None:
            h = float(rd.height)
        else:
            h = default
        offs.append(offs[-1] + h)
    return offs


def plan_bands(
    total_rows: int, band_rows: int | None = None, overlap: int | None = None
) -> list[tuple[int, int]]:
    """行バンド [(from, to)] (1-based, 両端含む)。小さいシートは単一バンド。"""
    band_rows = band_rows or settings.band_rows
    overlap = overlap if overlap is not None else settings.band_overlap
    overlap = min(overlap, band_rows - 1)
    if total_rows <= int(band_rows * 1.25):
        return [(1, max(total_rows, 1))]
    step = band_rows - overlap
    bands = []
    start = 1
    while True:
        end = min(start + band_rows - 1, total_rows)
        bands.append((start, end))
        if end >= total_rows:
            return bands
        start += step


def render_band(
    ctx: RenderContext,
    sheet: str,
    offsets: list[float],
    row_from: int,
    row_to: int,
    outdir: Path,
) -> Path:
    """行バンドを領域指定で PNG 化する。DPI は目標 px/行 から自動決定。"""
    page = ctx.pages[sheet]
    row_to = min(row_to, len(offsets) - 1)
    total = offsets[-1] or 1.0
    f0 = offsets[row_from - 1] / total
    f1 = offsets[row_to] / total
    band_pt = max((f1 - f0) * page.height_pt, 1e-3)
    rows = max(row_to - row_from + 1, 1)

    dpi = settings.target_px_per_row * rows * 72.0 / band_pt
    dpi = min(dpi, settings.band_img_max_width * 72.0 / max(page.width_pt, 1.0),
              float(settings.dpi_max))
    dpi = max(dpi, float(settings.dpi_min))
    px_per_row = band_pt / 72.0 * dpi / rows
    if px_per_row < 16:
        print(f"[warn] {sheet} r{row_from}-{row_to}: 幅制約で px/行={px_per_row:.0f}。"
              "横に広いシートです (列タイル分割は未実装)。", flush=True)

    y0 = int(f0 * page.height_pt / 72.0 * dpi)
    H = max(int(band_pt / 72.0 * dpi) + 1, 1)
    W = max(int(page.width_pt / 72.0 * dpi), 1)

    outdir = Path(outdir)
    outdir.mkdir(parents=True, exist_ok=True)
    prefix = outdir / f"band_{_safe_name(sheet)}_r{row_from}-{row_to}"
    cmd = [
        "pdftoppm", "-f", str(page.page_index), "-l", str(page.page_index),
        "-r", str(int(round(dpi))),
        "-x", "0", "-y", str(y0), "-W", str(W), "-H", str(H),
        "-png", str(ctx.pdf), str(prefix),
    ]
    subprocess.run(cmd, check=True, capture_output=True, timeout=600)
    outs = sorted(prefix.parent.glob(prefix.name + "-*.png"))
    if not outs:
        raise RuntimeError(f"pdftoppm がバンド画像を生成しませんでした: {prefix}")
    final = outdir / (prefix.name + ".png")
    outs[0].replace(final)
    for extra in outs[1:]:
        extra.unlink()
    return final


# ---------------------------------------------------------------- グリッドテキスト
def _fill_rgb(cell) -> str | None:
    try:
        f = cell.fill
        if f is None or f.patternType != "solid":
            return None
        rgb = getattr(f.start_color, "rgb", None)
        if not isinstance(rgb, str):
            return None  # テーマ色は解決せずスキップ
        if rgb in ("00000000", "FFFFFFFF"):
            return None
        return rgb
    except Exception:
        return None


def _rows_block(ws, r0: int, r1: int, max_col: int, colors: list[str]) -> list[str]:
    lines = []
    for r in range(r0, r1 + 1):
        rd = ws.row_dimensions.get(r)
        hidden = bool(rd is not None and rd.hidden)
        vals = []
        empty = True
        for c in range(1, max_col + 1):
            cell = ws.cell(row=r, column=c)
            v = cell.value
            s = "" if v is None else str(v).replace("\t", " ").replace("\n", "⏎")
            if s:
                empty = False
            vals.append(s)
            if len(colors) < MAX_COLOR_NOTES:
                rgb = _fill_rgb(cell)
                if rgb and s:
                    colors.append(f"{cell.coordinate}:{rgb}")
        if not empty:
            tag = f"{r}[非表示]" if hidden else str(r)
            lines.append("\t".join([tag] + vals))
    return lines


def sheet_grid_text(ws, row_from: int = 1, row_to: int | None = None,
                    header_rows: int = 0) -> str:
    """行バンドを行番号 (シート絶対行)・列レター付き TSV で表現する。

    row_from > header_rows のとき、ヘッダ行 (1..header_rows) を再掲する。
    結合セル・塗りはバンドと交差するもののみ付記する。
    """
    last = ws.max_row or 1
    row_to = min(row_to or last, last)
    row_from = max(1, min(row_from, row_to))
    max_col = min(ws.max_column or 1, MAX_GRID_COLS)
    col_truncated = (ws.max_column or 1) > MAX_GRID_COLS

    header = "\t".join([""] + [get_column_letter(c) for c in range(1, max_col + 1)])
    colors: list[str] = []
    lines = [header]

    if header_rows > 0 and row_from > header_rows:
        lines.append(f"── ヘッダ行 1〜{header_rows} (再掲) ──")
        lines += _rows_block(ws, 1, header_rows, max_col, colors)
        lines.append(f"── バンド本体 行{row_from}〜{row_to} ──")
    lines += _rows_block(ws, row_from, row_to, max_col, colors)

    parts = ["\n".join(lines)]
    merged = [
        str(rng) for rng in ws.merged_cells.ranges
        if rng.min_row <= row_to and rng.max_row >= row_from
    ]
    if merged:
        parts.append("結合セル (バンド交差分): " + ", ".join(merged[:MAX_MERGED_NOTES]))
    if colors:
        parts.append("塗りつぶしセル (座標:ARGB): " + ", ".join(colors))
    if col_truncated:
        parts.append(f"[注意] 列数が上限 ({MAX_GRID_COLS}) を超えたため右側を打ち切り。")
    text = "\n\n".join(parts)
    if len(text) > settings.grid_char_limit:
        text = text[: settings.grid_char_limit] + "\n[注意] 文字数上限で打ち切り。"
    return text
