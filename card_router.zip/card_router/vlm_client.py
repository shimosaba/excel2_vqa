"""vLLM (OpenAI 互換) クライアント。

- 構造化出力のパラメータは vLLM のバージョンで変遷しているため、
  response_format(json_schema) → extra_body.structured_outputs → extra_body.guided_json
  の順にフォールバックし、成功した方式をプロセス内でキャッシュする。
- Qwen3.5 はデフォルト thinking ON。通常は chat_template_kwargs で無効化し、
  有効化する場合はサーバ側 --reasoning-parser qwen3 前提で content には最終回答のみが
  乗る想定。保険として <think> ブロックの除去も行う。
"""
from __future__ import annotations

import asyncio
import base64
import io
import json
import re
from pathlib import Path
from typing import Type, TypeVar

from openai import AsyncOpenAI, BadRequestError
from PIL import Image, ImageOps
from pydantic import BaseModel, ValidationError

from config import settings

T = TypeVar("T", bound=BaseModel)

_PARAM_STYLES = ("response_format", "structured_outputs", "guided_json")
_working_style: str | None = None

_THINK_RE = re.compile(r"<think>.*?</think>", re.DOTALL)


def make_client() -> AsyncOpenAI:
    return AsyncOpenAI(
        base_url=settings.base_url,
        api_key=settings.api_key,
        timeout=settings.request_timeout,
    )


def image_to_data_url(path: str | Path, long_side: int | None, fmt: str = "PNG") -> str:
    """画像を読み込み、長辺を long_side に制限して data URL 化する。

    ビジョントークン量をクライアント側で決定的にコントロールするのが目的。
    シート画像は文字の潰れを避けるため PNG、名刺写真は JPEG で十分。
    """
    im = Image.open(path)
    im = ImageOps.exif_transpose(im)
    if im.mode != "RGB":
        im = im.convert("RGB")
    if long_side and max(im.size) > long_side:  # 0/None = リサイズしない (バンド画像はレンダ時にサイズ済み)
        im.thumbnail((long_side, long_side), Image.LANCZOS)
    buf = io.BytesIO()
    if fmt.upper() == "JPEG":
        im.save(buf, "JPEG", quality=90)
        mime = "image/jpeg"
    else:
        im.save(buf, "PNG")
        mime = "image/png"
    b64 = base64.b64encode(buf.getvalue()).decode()
    return f"data:{mime};base64,{b64}"


def _strip_think(text: str) -> str:
    text = _THINK_RE.sub("", text)
    if "</think>" in text:  # 開始タグ欠落ケース
        text = text.split("</think>")[-1]
    return text.strip()


def _extract_json(text: str) -> str:
    """先頭/末尾に混入したテキストから最初の JSON オブジェクトを切り出す保険。"""
    start = text.find("{")
    end = text.rfind("}")
    if start != -1 and end > start:
        return text[start : end + 1]
    return text


def _build_kwargs(
    style: str,
    messages: list[dict],
    schema_model: Type[BaseModel],
    max_tokens: int,
    think: bool,
) -> dict:
    schema = schema_model.model_json_schema()
    extra_body: dict = {
        "chat_template_kwargs": {"enable_thinking": bool(think)},
    }
    kwargs: dict = {
        "model": settings.model,
        "messages": messages,
        "max_tokens": max_tokens,
        "extra_body": extra_body,
    }
    if think:
        # 公式推奨 (thinking / general): temp=1.0, top_p=0.95, top_k=20, presence=1.5。
        # 構造化出力では presence_penalty を使わない (JSON 内の反復トークンを歪める)。
        kwargs["temperature"] = settings.thinking_temperature
        kwargs["top_p"] = settings.thinking_top_p
        extra_body["top_k"] = settings.thinking_top_k
    else:
        kwargs["temperature"] = settings.temperature

    if style == "response_format":
        kwargs["response_format"] = {
            "type": "json_schema",
            "json_schema": {"name": schema_model.__name__, "schema": schema},
        }
    elif style == "structured_outputs":
        extra_body["structured_outputs"] = {"json": schema}
    elif style == "guided_json":
        extra_body["guided_json"] = schema
    return kwargs


async def structured_chat(
    client: AsyncOpenAI,
    messages: list[dict],
    schema_model: Type[T],
    *,
    max_tokens: int,
    think: bool = False,
    retries: int = 1,
) -> T:
    """スキーマ準拠 JSON を強制して 1 リクエスト実行し、Pydantic で検証して返す。"""
    global _working_style
    styles = list(_PARAM_STYLES)
    if _working_style:
        styles.remove(_working_style)
        styles.insert(0, _working_style)

    last_err: Exception | None = None
    for attempt in range(retries + 1):
        for style in styles:
            kwargs = _build_kwargs(style, messages, schema_model, max_tokens, think)
            try:
                resp = await client.chat.completions.create(**kwargs)
            except BadRequestError as e:
                last_err = e  # この方式が未対応 → 次の方式へ
                continue
            content = resp.choices[0].message.content or ""
            content = _strip_think(content)
            try:
                out = schema_model.model_validate_json(_extract_json(content))
                _working_style = style
                return out
            except ValidationError as e:
                # パラメータが黙殺され非構造化出力になった等 → 次の方式で再試行
                last_err = e
                continue
        await asyncio.sleep(1.0)
    raise RuntimeError(
        f"structured_chat failed for {schema_model.__name__}: {last_err}"
    ) from last_err


def text_part(text: str) -> dict:
    return {"type": "text", "text": text}


def image_part(data_url: str) -> dict:
    return {"type": "image_url", "image_url": {"url": data_url}}


def dump_json(model: BaseModel) -> str:
    return json.dumps(
        model.model_dump(exclude_none=True), ensure_ascii=False, separators=(",", ":")
    )
