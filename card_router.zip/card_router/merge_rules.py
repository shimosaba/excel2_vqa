"""シート抽出結果 → Rulebook。マージは機械的に行い、LLM は検出のみに使う (解決は人間)。"""
from __future__ import annotations

import re

from datetime import date

from openai import AsyncOpenAI

from config import settings
from normalize import normalize_text
from schemas import (
    BusinessRule,
    Conflict,
    ConflictScan,
    Rulebook,
    RuleCondition,
    SheetExtraction,
)
from vlm_client import structured_chat, text_part


def _norm_cond(c: RuleCondition) -> tuple:
    if c.op == "regex":
        vals = tuple(sorted(c.values))  # 正規表現は正規化するとパターンが壊れる
    else:
        vals = tuple(sorted(normalize_text(v) for v in c.values))
    return (c.field, c.op, vals)


def rule_signature(r: BusinessRule) -> tuple:
    return (
        frozenset(_norm_cond(c) for c in r.when_all),
        frozenset(_norm_cond(c) for c in r.when_any),
        frozenset(_norm_cond(c) for c in r.exceptions),
    )


_ROW_RE = re.compile(r"(\d+)")


def _first_row(cell_range: str) -> int:
    """cell_range 文字列から先頭の行番号を取り出す (出典行順ソート用)。"""
    m = _ROW_RE.search(cell_range or "")
    return int(m.group(1)) if m else 10**9


def _assign_sentinel_priorities(rules: list[BusinessRule], conflicts: list[Conflict]) -> None:
    """priority=0 (未明記 sentinel) をシートごとに出典行順で自動採番する。

    - シート内が全て未明記: 10, 20, 30, ... を行順で付与 (挿入調整の余地を残す)。
    - 明記と未明記が混在: 未明記分を明記の最大値より後ろ (低優先) に採番し、
      priority_mixed として人間レビューへ回す。0 のまま残すと「1 が最高優先」の
      規約上、最優先扱いになってしまうため必ず採番する。
    """
    by_sheet: dict[str, list[BusinessRule]] = {}
    for r in rules:
        by_sheet.setdefault(r.source.sheet, []).append(r)
    for sheet, group in by_sheet.items():
        sentinels = [r for r in group if r.priority == 0]
        if not sentinels:
            continue
        explicit = [r for r in group if r.priority != 0]
        base = 0
        if explicit:
            base = max(r.priority for r in explicit)
            conflicts.append(
                Conflict(
                    kind="priority_mixed",
                    rule_ids=[r.rule_id for r in sentinels],
                    detail=f"シート「{sheet}」で優先度の明記/未明記が混在。"
                    f"未明記分は明記の後ろ (>{base}) に出典行順で自動採番した。要確認。",
                )
            )
        sentinels.sort(key=lambda r: (_first_row(r.source.cell_range), r.rule_id))
        for i, r in enumerate(sentinels, start=1):
            r.priority = base + 10 * i


def merge(extractions: list[SheetExtraction], source_file: str) -> Rulebook:
    rules: list[BusinessRule] = []
    conflicts: list[Conflict] = []
    cross_refs: list[str] = []
    unparsed: list[str] = []

    seen_ids: set[str] = set()
    for si, ext in enumerate(extractions, start=1):
        cross_refs += [f"[{ext.sheet_name}] {c}" for c in ext.cross_references]
        unparsed += [f"[{ext.sheet_name}] {n}" for n in ext.unparsed_notes]
        for r in ext.rules:
            rid = f"S{si:02d}-{r.rule_id}"
            n = 2
            while rid in seen_ids:
                rid = f"S{si:02d}-{r.rule_id}_{n}"
                n += 1
            seen_ids.add(rid)
            r = r.model_copy(update={"rule_id": rid})
            r.source.sheet = ext.sheet_name
            rules.append(r)

    # 条件シグネチャ同一の検出: 完全重複は落とし、アクション相違はコンフリクト報告
    by_sig: dict[tuple, list[BusinessRule]] = {}
    for r in rules:
        by_sig.setdefault(rule_signature(r), []).append(r)

    kept: list[BusinessRule] = []
    for sig, group in by_sig.items():
        if len(group) == 1:
            kept.append(group[0])
            continue
        actions = {normalize_text(g.action) for g in group}
        if len(actions) == 1:
            kept.append(group[0])  # 代表 1 件を残す
            conflicts.append(
                Conflict(
                    kind="duplicate_rule",
                    rule_ids=[g.rule_id for g in group],
                    detail=f"条件・アクションが同一の重複。{group[0].rule_id} のみ採用。",
                )
            )
        else:
            kept.extend(group)  # 判断は人間へ。全件残して報告する。
            conflicts.append(
                Conflict(
                    kind="same_condition_diff_action",
                    rule_ids=[g.rule_id for g in group],
                    detail="同一条件で異なるアクション。要人間レビュー: "
                    + " / ".join(f"{g.rule_id}→{g.action}" for g in group),
                )
            )

    _assign_sentinel_priorities(kept, conflicts)
    kept.sort(key=lambda r: (r.priority, r.rule_id))
    return Rulebook(
        version=date.today().isoformat(),
        source_file=source_file,
        rules=kept,
        conflicts=conflicts,
        cross_references=cross_refs,
        unparsed_notes=unparsed,
    )


_SCAN_PROMPT = """あなたは業務ルールブックの検査器です。以下の JSON ルール群を読み、
(1) 意味的に重複しているルール、(2) 同一の名刺が複数ルールに同順位 (同 priority) で
該当し得てアクションが異なる組み合わせ、を検出してください。
解決はしないでください。検出結果のみを指定スキーマで出力します。無ければ空リスト。"""


async def llm_conflict_scan(client: AsyncOpenAI, rulebook: Rulebook) -> list[Conflict]:
    """任意実行の意味的コンフリクトスキャン (検出のみ)。"""
    import json

    rules_json = json.dumps(
        [r.model_dump(exclude_none=True) for r in rulebook.rules],
        ensure_ascii=False,
    )
    messages = [
        {"role": "system", "content": _SCAN_PROMPT},
        {"role": "user", "content": [text_part(rules_json)]},
    ]
    out = await structured_chat(
        client, messages, ConflictScan, max_tokens=settings.max_tokens_extract, think=False
    )
    known = rulebook.rule_ids()
    return [c for c in out.conflicts if set(c.rule_ids) & known]
