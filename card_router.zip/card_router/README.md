# card_router — 名刺ルーティングパイプライン (Qwen3.5-27B / vLLM)

業務内容 Excel から構造化ルールブックを構築し、名刺画像を
「決定的ルールエンジン + LLM judge (rulebook-as-context)」でルーティングする。
**1シート1000行超・図形/埋め込み画像多数の Excel を前提**にした行バンド処理設計。

```
Excel ──(LibreOffice: SinglePageSheets, 1回だけ)──> PDF (1シート=1ページ)
  │                                                   │ pdftoppm -y/-H 領域レンダ
  │ (openpyxl data_only)                              ▼ DPI自動 (目標32px/行)
  ├─> グリッドTSV バンドスライス ──┐            バンド画像 (行150+重なり20)
  │    ヘッダ再掲・結合セル・塗り   ├──> VLM 1段抽出 (SheetExtraction JSON)
  │ (zip直読み: drawings.py)       │      バンドごと / priority未明記=0
  ├─> 図形・テキストボックス文字 ──┘            │
  └─> 埋め込み画像 ──小図はバンド添付／大図はfigureパス個別抽出
                                                   ▼
              機械的マージ: シグネチャdedupe (バンド重複吸収)
              + sentinel priority を出典行順に自動採番 → rulebook.json
                                                   │ conflicts は人間レビュー
名刺画像 ─> VLM (CardFields) ─> 正規化 ─> 決定的エンジン(三値評価)
                     ├ decided → 採用 (engine)
                     ├ tie / UNKNOWN → 候補を絞って judge → 採用/abstain
                     └ no_match → ルールブック全体で judge (既定)
```

## セットアップ

```bash
pip install -r requirements.txt
sudo apt install libreoffice-calc poppler-utils fonts-noto-cjk   # システム依存
```

- LibreOffice **7.4 以上**必須 (CLI JSON 形式の `SinglePageSheets` フィルタを使用)。
- 実測 (LO 24.2): SinglePageSheets はページ高さ **12,862.5pt を上限に全体を一様縮小**する
  (クリップ無し・ベクタ保持)。必要な解像度はバンドごとの DPI 自動決定で取り返す。
- 日本語フォントが無いとシート画像が豆腐化する。

## vLLM サーバ

```bash
uv pip install -U vllm --torch-backend=auto   # 現行安定版で Qwen3.5 対応
./serve_vllm.sh                               # H100/H200 1枚 BF16 デフォルト
```

GPU 別の変更点 (L40S=FP8 or TP2 / A100=BF16 のみ / MTP / prefix caching) は
`serve_vllm.sh` 内コメント参照。`--reasoning-parser qwen3` は常時付ける。

## 使い方

```bash
# 1. ルールブック構築 (--conflict-scan で LLM 意味的重複検出も実行)
python3 pipeline.py build-rulebook rules.xlsx -o rulebook.json --conflict-scan

# 2. ルーティング
python3 pipeline.py route card.jpg --rulebook rulebook.json
python3 pipeline.py route-batch cards/ --rulebook rulebook.json -o results.jsonl

# 3. 評価 (labels.csv: card,gold。gold="REJECT" は abstain が正解)
python3 evaluate.py results.jsonl labels.csv -o eval_out/

# テスト
python3 tests_local.py         # サーバ・LibreOffice 不要 (11本)
python3 tests_integration.py   # LibreOffice 実機 E2E (図形注入・写像精度)
```

## Docker

パイプライン本体のみをコンテナ化する (vLLM サーバは含めず `VLLM_BASE_URL` で外部を指す)。
ベースは検証済み環境と同一の `ubuntu:24.04` (LibreOffice 24.2 / Python 3.12)。
イメージサイズは LibreOffice + CJK フォント込みで 1GB 弱。

```bash
docker build -t card-router .

# 同一ホストの vLLM (:8000) を使う場合 (Linux は --network host が最短)
docker run --rm --network host -v "$PWD:/data" card-router \
  build-rulebook rules.xlsx -o rulebook.json --conflict-scan
docker run --rm --network host -v "$PWD:/data" card-router \
  route-batch cards/ --rulebook rulebook.json -o results.jsonl

# ブリッジネットワークで同一ホストの vLLM を指す場合
docker run --rm --add-host=host.docker.internal:host-gateway \
  -e VLLM_BASE_URL=http://host.docker.internal:8000/v1 \
  -v "$PWD:/data" card-router route card.jpg --rulebook rulebook.json

# 別ホストの vLLM: -e VLLM_BASE_URL=http://<serving-host>:8000/v1

# コンテナ自己検証 (LibreOffice 実機 E2E がコンテナ内で通るかのスモーク)
docker run --rm --entrypoint python3 card-router /app/tests_integration.py

# 評価
docker run --rm -v "$PWD:/data" --entrypoint python3 card-router \
  /app/evaluate.py results.jsonl labels.csv -o eval_out
```

WORKDIR は `/data` なので、`-v "$PWD:/data"` を付ければ相対パス指定の
出力 (rulebook.json / renders/ / results.jsonl) がそのままホスト側に落ちる。

## バンド処理のパラメータ (環境変数)

| 変数 | 既定 | 意味 |
|---|---|---|
| `CARD_ROUTER_BAND_ROWS` | 150 | 1バンドの行数 |
| `CARD_ROUTER_BAND_OVERLAP` | 20 | 隣接バンドの重なり行数 (写像誤差・表の跨ぎを吸収) |
| `CARD_ROUTER_HEADER_ROWS` | 4 | 毎バンド再掲するヘッダ行数 |
| `CARD_ROUTER_PX_PER_ROW` | 32 | 領域レンダの目標 px/行 (24〜45 推奨) |
| `CARD_ROUTER_BAND_MAX_W` | 2400 | バンド画像の最大幅 px (これが DPI を律速することあり) |
| `CARD_ROUTER_FIGURE_MIN_PX` | 480 | 長辺がこれ以上の埋め込み画像は figure パスで個別抽出 |
| `CARD_ROUTER_MAX_BAND_IMGS` | 4 | バンドに添付する小画像の上限 |

他: `VLLM_BASE_URL` `CARD_ROUTER_MODEL` `CARD_ROUTER_CONCURRENCY`
`CARD_ROUTER_JUDGE_THINK=1` など → `config.py`。

## 設計要点

1. **抽出は 1 段** — シート画像+セルグリッドを併給しスキーマ準拠 JSON を直接出す。
   `extra="forbid"` で guided decoding の文法を閉じる。文字はグリッド優先、画像はレイアウト解釈用。
2. **バンド分割** — 1000行超シートは 1 リクエストに載せない。行バンドごとに
   「領域レンダ画像 + グリッドスライス + 図形テキスト」で抽出し、シート単位に結合して
   rule_id を通し番号に振り直す。バンド重複はマージのシグネチャ dedupe が吸収。
3. **図形・画像はレンダ画像に依存しない** — `drawings.py` が xlsx (zip) の DrawingML を
   直読みし、テキストボックス文字列をアンカー行付きで回収 (縮小の影響を受けない)。
   埋め込み画像は小図=バンド添付、大図=figure パス個別抽出。グラフは位置のみ記録。
4. **マージは機械的** — 重複除去・conflict 検出のみ。解決は人間。
   priority 未明記 (sentinel=0) はシートごとに出典行順で 10,20,30… と自動採番。
   明記と混在したら未明記分を後ろに回して `priority_mixed` で人間レビューへ
   (0 のまま残すと「1 が最高優先」の規約上、最優先に化けるため必ず採番する)。
5. **最終判定は類似度ではない** — 三値評価エンジンが「適用可能な全ルール列挙 → priority
   解決」を行い、UNKNOWN が勝敗に影響し得る場合のみ judge へ (低優先 UNKNOWN は無視)。
   ルールブックが肥大したら top-k retrieval を足す位置は `pipeline.route_one` の候補構築部。
6. **margin = 構造化出力** — judge は列挙→選択→abstain/confidence。`sanitize_verdict` で防御。
7. **prefix caching 前提の配置** — judge はルールブックを system に固定 (GDN 系 align
   モードは実験的、詳細 serve_vllm.sh)。
8. **サンプリング** — 公式推奨の presence_penalty=1.5 は JSON 抽出では不使用 (反復トークンを
   歪める)。抽出/判定は temperature=0。

## 制約・既知の注意

- 図形テキストは mc:AlternateContent の **Choice 側のみ**辿る (Fallback は二重計上防止で
  スキップ)。absoluteAnchor (セル非依存配置) は行不明 → 行1 扱い+注記。
- グラフ (graphicFrame) の中身は抽出しない (位置のみバンドに注記、画像で見せる)。
- 横に極端に広いシートは `BAND_MAX_W` が DPI を律速し px/行 が下がる (16 未満で警告)。
  列方向のタイル分割は未実装。
- `data_only=True` は Excel 保存時の数式キャッシュ値前提。
- 非表示行は印刷されない (画像に出ない) が、グリッドには `[非表示]` 付きで含める。
- `route-batch` はスキャン画像前提。表裏 2 枚 1 件は `route_one` 呼び出し側で拡張。

## ファイル構成

| ファイル | 役割 |
|---|---|
| `config.py` | エンドポイント/サンプリング/バンド設定 |
| `schemas.py` | Pydantic スキーマ (guided decoding の語彙固定) |
| `normalize.py` | NFKC + 法人格統一 + 空白除去 + casefold |
| `excel_render.py` | SinglePageSheets → 領域レンダ + 行高写像 + バンドグリッド |
| `drawings.py` | DrawingML 直読み (図形テキスト/埋め込み画像+アンカー行) |
| `extract_rules.py` | バンド/figure → SheetExtraction (1段抽出) + シート結合 |
| `merge_rules.py` | 機械的マージ + sentinel priority 採番 + conflict 検出 |
| `card_extract.py` | 名刺画像 → CardFields |
| `rule_engine.py` | 決定的エンジン (三値評価・priority 解決) |
| `judge.py` | LLM judge (列挙→解決→abstain, sanitize) |
| `pipeline.py` | CLI (build-rulebook / route / route-batch) |
| `evaluate.py` | risk-coverage 評価 |
| `serve_vllm.sh` | GPU 別 vLLM 起動 |
| `Dockerfile` / `.dockerignore` | パイプライン実行イメージ (vLLM 非同梱) |
| `tests_local.py` / `tests_integration.py` | ユニット 11 本 / LO 実機 E2E |
