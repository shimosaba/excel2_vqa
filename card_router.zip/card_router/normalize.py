"""表記ゆれ正規化。

ルール条件と名刺フィールドの両方を同じ関数に通し、正規化後の文字列同士で照合する。
- NFKC (全角英数/半角カナ/囲み文字の正規化。㈱→(株) もここで展開される)
- 法人格の略記統一
- 空白 (半角/全角) 除去
- ASCII casefold
"""
from __future__ import annotations

import re
import unicodedata

# NFKC 適用後に置換する (㈱ は NFKC で "(株)" になるため後段でまとめて拾える)
_REPLACEMENTS = [
    ("(株)", "株式会社"),
    ("(有)", "有限会社"),
    ("(合)", "合同会社"),
    ("(社)", "社団法人"),
    ("(財)", "財団法人"),
]

_WS_RE = re.compile(r"[\s\u3000]+")


def normalize_text(s: str | None) -> str:
    if not s:
        return ""
    s = unicodedata.normalize("NFKC", s)
    for src, dst in _REPLACEMENTS:
        s = s.replace(src, dst)
    s = _WS_RE.sub("", s)
    return s.casefold()


def email_domain(email: str | None) -> str:
    if not email or "@" not in email:
        return ""
    return email.rsplit("@", 1)[1].strip().casefold()


def normalize_card_fields(card) -> dict[str, str]:
    """CardFields -> {field名: 正規化済み文字列}。rule_engine の照合対象。

    空文字は「情報なし」を意味し、engine 側では UNKNOWN 扱い (judge へ回す)。
    """
    d = {
        "company": normalize_text(card.company),
        "department": normalize_text(card.department),
        "title": normalize_text(card.title),
        "person_name": normalize_text(card.person_name),
        "email": (card.email or "").strip().casefold(),
        "email_domain": email_domain(card.email),
        "phone": normalize_text(card.phone),
        "address": normalize_text(card.address),
        "other": normalize_text(" ".join(card.other_text)),
    }
    return d
