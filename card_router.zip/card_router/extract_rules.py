"""シート単位のルール抽出 (バンド分割 + figure パス)。

- 1 シートを行バンドに分割し、各バンドに「領域レンダ画像 + グリッドスライス +
  図形テキスト (+小さい埋め込み画像)」を渡して SheetExtraction を 1 段で出力させる。
- 大きい埋め込み画像 (フロー図・別表画像など) は figure パスで個別に同スキーマ抽出。
- バンド/figure の結果はシート単位に結合し、rule_id をシート通し番号に振り直す。
  オーバーラップ由来の重複ルールは merge_rules のシグネチャ dedupe が吸収する。
"""
from __future__ import annotations

import asyncio
from pathlib import Path

from openai import AsyncOpenAI
from openpyxl import load_workbook

from config import settings
from drawings import EmbeddedImage, SheetDrawings, ShapeText, extract_drawings
from excel_render import (
    RenderContext,
    build_render_context,
    plan_bands,
    render_band,
    row_offsets,
    sheet_grid_text,
)
from schemas import SheetExtraction
from vlm_client import image_part, image_to_data_url, structured_chat, text_part

SYSTEM_PROMPT = """あなたは業務ルール抽出器です。入力は業務ルールが書かれた Excel シートの
「行バンド (シートの一部)」で、以下で構成されます:
- セルグリッドテキスト (行番号・列レター付き TSV。行番号はシートの絶対行番号)
- 図形/テキストボックス内の文字列 (アンカー行付き。セルには存在しない文字情報)
- バンド範囲のレンダリング画像 (+ この範囲に埋め込まれた画像)
出力は指定スキーマに準拠した JSON のみです。

抽出方針:
- 1 ルール = 1 判定単位。表の 1 行が 1 ルールとは限らない。条件とアクションの対応が
  独立に判定できる単位に分割する。
- rule_id はこのバンド内で "R1", "R2", ... と連番 (後段でシート通し番号に振り直される)。
- 条件は field (company/department/title/person_name/email/email_domain/phone/address/other)
  に正規化する。表記そのままの値を values に入れる (正規化はコード側で行う)。
- 「〜っぽい」「役員クラス」「研究開発系の部署」など決定的照合に落とせない条件は
  op="semantic" とし、values に条件の自然文を 1 要素で入れる。無理に equals へ潰さない。
- 但し書き・除外条件 (「ただし〜は除く」など) は必ず exceptions に入れる。
- 優先度: シートに明記があれば数値化する (1 が最高)。明記が無ければ 0 を入れる
  (後段でシート全体の出典行順に自動採番される)。バンド内で勝手に序列を作らない。
- source.cell_range は必ずグリッドの絶対行番号で入れる (例 "B415:D415")。
  図形テキスト由来のルールはアンカー行を使う (例 "E210 図形")。
- バンド境界で表が途切れている場合、判定単位として完結している行のみルール化し、
  条件やアクションが読み切れない行は unparsed_notes に「行Nで途切れ」と記録する。
- 「ヘッダ行 (再掲)」は列の意味の解釈にのみ使い、ルールとして抽出しない。
- 「別紙」「別表」「○○シート参照」等のシート間参照は cross_references に記述を残す。
- グラフの中身がルールを含むように見える場合は unparsed_notes に記録する
  (グラフからの抽出はしない。文字はグリッド/図形テキストを優先)。
- スキーマに落とせない注記・判読不能箇所は捨てずに unparsed_notes へ入れる。
- 書かれていない条件を推測で補わない。非表示行 ([非表示] 付き) も抽出対象だが、
  notes に「非表示行由来」と残す。"""

FIGURE_PROMPT = """あなたは業務ルール抽出器です。入力は業務 Excel シートに埋め込まれた
画像 1 枚 (フロー図・別表画像など) と、そのアンカー位置周辺のセルグリッドです。
出力は指定スキーマに準拠した JSON のみです。
- 画像内に業務ルール (条件→処理) が明確に読み取れる場合のみ rules に抽出する。
  条件の field 正規化・semantic・exceptions・優先度未明記=0 の規則はセル由来と同じ。
- ルールを含まない図 (写真・装飾・単なる説明図) の場合は rules を空にし、
  図の要旨を unparsed_notes に 1 行で残す。
- source.cell_range にはアンカー位置を入れる (例 "C210 埋め込み画像")。
- 書かれていない条件を推測で補わない。"""


def _shape_lines(shapes: list[ShapeText]) -> list[str]:
    out = []
    for s in shapes:
        span = f"行{s.row}" + (f"〜{s.row_to}" if s.row_to and s.row_to != s.row else "")
        loc = span if s.anchored else f"{span} (絶対配置・行不確定)"
        out.append(f"[{loc}] ({s.kind}:{s.name}) {s.text.replace(chr(10), ' / ')}")
    return out


def build_band_text(
    sheet: str, total_rows: int, r0: int, r1: int, grid: str,
    shapes: list[ShapeText], chart_rows: list[int], n_small_imgs: int,
) -> str:
    parts = [
        f"シート名: {sheet}\n"
        f"この入力はシート全 {total_rows} 行のうち 行{r0}〜{r1} のバンドです。\n\n"
        f"=== セルグリッドテキスト ===\n{grid}"
    ]
    if shapes:
        parts.append(
            "=== 図形/テキストボックス文字列 (セルには無い情報・アンカー行付き) ===\n"
            + "\n".join(_shape_lines(shapes))
        )
    if chart_rows:
        parts.append(f"※この範囲にグラフ {len(chart_rows)} 個 (アンカー行: {chart_rows})。内容は画像を参照。")
    if n_small_imgs:
        parts.append(f"※この範囲の埋め込み画像 {n_small_imgs} 枚を追加画像として添付。")
    parts.append(f"=== レンダリング画像 (行{r0}〜{r1}) は以下 ===")
    return "\n\n".join(parts)


async def extract_band(
    client: AsyncOpenAI,
    ctx: RenderContext,
    ws,
    sheet: str,
    offsets: list[float],
    total_rows: int,
    r0: int,
    r1: int,
    shapes: list[ShapeText],
    chart_rows: list[int],
    small_imgs: list[EmbeddedImage],
    band_dir: Path,
) -> SheetExtraction:
    img = await asyncio.to_thread(render_band, ctx, sheet, offsets, r0, r1, band_dir)
    grid = sheet_grid_text(ws, r0, r1, header_rows=settings.header_rows)
    content = [
        text_part(build_band_text(sheet, total_rows, r0, r1, grid, shapes, chart_rows,
                                  min(len(small_imgs), settings.max_band_images))),
        image_part(image_to_data_url(img, None, fmt="PNG")),  # レンダ時にサイズ済み
    ]
    for im in small_imgs[: settings.max_band_images]:
        content.append(image_part(image_to_data_url(im.path, 1024, fmt="PNG")))
    out = await structured_chat(
        client,
        [{"role": "system", "content": SYSTEM_PROMPT},
         {"role": "user", "content": content}],
        SheetExtraction,
        max_tokens=settings.max_tokens_extract,
        think=False,
    )
    tag = f"[{sheet} 行{r0}-{r1}]"
    return out.model_copy(update={
        "sheet_name": sheet,
        "cross_references": [f"{tag} {c}" for c in out.cross_references],
        "unparsed_notes": [f"{tag} {n}" for n in out.unparsed_notes],
    })


async def extract_figure(
    client: AsyncOpenAI, ws, sheet: str, fig: EmbeddedImage
) -> SheetExtraction:
    ctx_grid = sheet_grid_text(
        ws,
        max(1, fig.row - settings.figure_ctx_rows),
        fig.row + settings.figure_ctx_rows,
        header_rows=0,
    )
    anchor = f"{'行' + str(fig.row) if fig.anchored else '行不明 (絶対配置)'}"
    content = [
        text_part(
            f"シート名: {sheet}\n埋め込み画像 (名称: {fig.name or '無名'}, アンカー: {anchor}, "
            f"{fig.width}x{fig.height}px)\n\n=== アンカー周辺のセルグリッド ===\n{ctx_grid}\n\n"
            "=== 画像は以下 ==="
        ),
        image_part(image_to_data_url(fig.path, 1600, fmt="PNG")),
    ]
    out = await structured_chat(
        client,
        [{"role": "system", "content": FIGURE_PROMPT},
         {"role": "user", "content": content}],
        SheetExtraction,
        max_tokens=settings.max_tokens_extract,
        think=False,
    )
    tag = f"[{sheet} 図@{anchor}]"
    return out.model_copy(update={
        "sheet_name": sheet,
        "cross_references": [f"{tag} {c}" for c in out.cross_references],
        "unparsed_notes": [f"{tag} {n}" for n in out.unparsed_notes],
    })


def _combine(sheet: str, parts: list[SheetExtraction]) -> SheetExtraction:
    """バンド/figure の結果をシート単位に結合し、rule_id をシート通し番号へ。"""
    rules, cross, notes = [], [], []
    i = 1
    for p in parts:
        for r in p.rules:
            rules.append(r.model_copy(update={"rule_id": f"R{i}"}))
            i += 1
        cross += p.cross_references
        notes += p.unparsed_notes
    return SheetExtraction(
        sheet_name=sheet,
        rules=rules,
        cross_references=list(dict.fromkeys(cross)),
        unparsed_notes=list(dict.fromkeys(notes)),
    )


async def extract_workbook(
    client: AsyncOpenAI, xlsx: Path, workdir: Path
) -> list[SheetExtraction]:
    xlsx = Path(xlsx)
    workdir = Path(workdir)
    workdir.mkdir(parents=True, exist_ok=True)

    ctx = build_render_context(xlsx, workdir)
    wb = load_workbook(xlsx, data_only=True)
    all_drawings = extract_drawings(xlsx, workdir / "media")
    band_dir = workdir / "bands"

    sem = asyncio.Semaphore(settings.concurrency)
    jobs: list[tuple[str, int, asyncio.Future]] = []  # (sheet, order_key, coro)

    async def _run(sheet: str, label: str, coro):
        async with sem:
            print(f"[extract] {sheet} {label} ...", flush=True)
            return await coro

    tasks = []
    order = []
    for sheet in ctx.pages:
        ws = wb[sheet]
        sd = all_drawings.get(sheet) or SheetDrawings()
        total_rows = max(ws.max_row or 1, sd.max_row())
        offsets = row_offsets(ws, total_rows)
        figures = [i for i in sd.images if max(i.width, i.height) >= settings.figure_min_long_side]
        small = [i for i in sd.images if i not in figures]

        for bi, (r0, r1) in enumerate(plan_bands(total_rows)):
            shapes_in = [s for s in sd.shapes if s.row <= r1 and (s.row_to or s.row) >= r0]
            charts_in = [cr for cr in sd.chart_rows if r0 <= cr <= r1]
            small_in = [im for im in small if im.row <= r1 and (im.row_to or im.row) >= r0]
            coro = extract_band(client, ctx, ws, sheet, offsets, total_rows,
                                r0, r1, shapes_in, charts_in, small_in, band_dir)
            tasks.append(_run(sheet, f"r{r0}-{r1}", coro))
            order.append((sheet, bi))
        for fi, fig in enumerate(figures):
            tasks.append(_run(sheet, f"figure@{fig.row}", extract_figure(client, ws, sheet, fig)))
            order.append((sheet, 100_000 + fi))

    results = await asyncio.gather(*tasks)
    per_sheet: dict[str, list[tuple[int, SheetExtraction]]] = {}
    for (sheet, key), res in zip(order, results):
        per_sheet.setdefault(sheet, []).append((key, res))
    return [
        _combine(sheet, [r for _, r in sorted(items, key=lambda t: t[0])])
        for sheet, items in ((s, per_sheet[s]) for s in ctx.pages if s in per_sheet)
    ]
