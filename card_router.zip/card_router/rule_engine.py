"""決定的ルールエンジン。

三値評価 (TRUE / FALSE / UNKNOWN) で判定する:
- semantic 条件 → UNKNOWN (judge 送り)
- 対象フィールドが空 (名刺から取れていない) → UNKNOWN
  肯定条件は「確認できない」、否定条件も「不在を確認できない」ため両方 UNKNOWN。

route() は「適用可能な全ルールを列挙 → priority で解決」を行い、
UNKNOWN が勝敗に影響し得る場合のみ judge へエスカレーションする。
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from enum import Enum

from normalize import normalize_text
from schemas import BusinessRule, RuleCondition, Rulebook


class Tri(Enum):
    TRUE = 1
    FALSE = 0
    UNKNOWN = -1


def eval_condition(cond: RuleCondition, fields: dict[str, str]) -> Tri:
    target = fields.get(cond.field, "")
    if cond.op == "semantic":
        return Tri.UNKNOWN
    if not target:
        return Tri.UNKNOWN

    if cond.op in ("equals", "not_equals"):
        hit = any(target == normalize_text(v) for v in cond.values)
    elif cond.op in ("contains", "not_contains"):
        hit = any(normalize_text(v) and normalize_text(v) in target for v in cond.values)
    elif cond.op == "regex":
        try:
            hit = any(re.search(p, target) for p in cond.values)
        except re.error:
            return Tri.UNKNOWN  # 壊れた正規表現は judge へ
    else:
        return Tri.UNKNOWN

    if cond.op.startswith("not_"):
        hit = not hit
    return Tri.TRUE if hit else Tri.FALSE


def _eval_all(conds: list[RuleCondition], fields: dict[str, str]) -> Tri:
    if not conds:
        return Tri.TRUE
    results = [eval_condition(c, fields) for c in conds]
    if Tri.FALSE in results:
        return Tri.FALSE
    if Tri.UNKNOWN in results:
        return Tri.UNKNOWN
    return Tri.TRUE


def _eval_any(conds: list[RuleCondition], fields: dict[str, str], empty: Tri) -> Tri:
    if not conds:
        return empty
    results = [eval_condition(c, fields) for c in conds]
    if Tri.TRUE in results:
        return Tri.TRUE
    if Tri.UNKNOWN in results:
        return Tri.UNKNOWN
    return Tri.FALSE


def rule_applicability(rule: BusinessRule, fields: dict[str, str]) -> Tri:
    base_all = _eval_all(rule.when_all, fields)
    base_any = _eval_any(rule.when_any, fields, empty=Tri.TRUE)
    if Tri.FALSE in (base_all, base_any):
        return Tri.FALSE
    excluded = _eval_any(rule.exceptions, fields, empty=Tri.FALSE)
    if excluded == Tri.TRUE:
        return Tri.FALSE
    if base_all == base_any == Tri.TRUE and excluded == Tri.FALSE:
        return Tri.TRUE
    return Tri.UNKNOWN


@dataclass
class EngineResult:
    """エンジン単体の判定結果。decided=False なら judge へ。"""

    decided: bool
    selected: BusinessRule | None = None
    applicable: list[str] = field(default_factory=list)  # MATCH した rule_id 全件
    candidates: list[BusinessRule] = field(default_factory=list)  # judge に渡す候補
    tie: bool = False  # 同順位・異アクションの競合か
    no_match: bool = False  # MATCH も UNKNOWN も無し
    rationale: str = ""


def route(rulebook: Rulebook, fields: dict[str, str]) -> EngineResult:
    matches: list[BusinessRule] = []
    unknowns: list[BusinessRule] = []
    for r in rulebook.rules:
        a = rule_applicability(r, fields)
        if a == Tri.TRUE:
            matches.append(r)
        elif a == Tri.UNKNOWN:
            unknowns.append(r)

    applicable_ids = [r.rule_id for r in matches]

    if not matches and not unknowns:
        return EngineResult(decided=False, no_match=True, rationale="該当ルールなし (決定的評価)")

    if matches:
        best_p = min(r.priority for r in matches)
        winners = [r for r in matches if r.priority == best_p]
        # UNKNOWN のうち、勝者より優先度が高い/同じものだけが結果を覆し得る
        blocking = [u for u in unknowns if u.priority <= best_p]
        if not blocking:
            if len(winners) == 1 or len({normalize_text(w.action) for w in winners}) == 1:
                w = winners[0]
                return EngineResult(
                    decided=True,
                    selected=w,
                    applicable=applicable_ids,
                    rationale=f"決定的一致 (priority={best_p})",
                )
            return EngineResult(
                decided=False,
                applicable=applicable_ids,
                candidates=winners,
                tie=True,
                rationale=f"同順位 (priority={best_p}) で異なるアクションが競合",
            )
        cand = {r.rule_id: r for r in winners + blocking}
        return EngineResult(
            decided=False,
            applicable=applicable_ids,
            candidates=sorted(cand.values(), key=lambda r: (r.priority, r.rule_id)),
            rationale="優先度に影響する未確定 (semantic/情報欠落) 条件あり",
        )

    return EngineResult(
        decided=False,
        candidates=sorted(unknowns, key=lambda r: (r.priority, r.rule_id)),
        rationale="決定的一致なし。未確定ルールのみ候補",
    )
